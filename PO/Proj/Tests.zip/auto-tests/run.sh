#!/bin/sh


ORIG_DIR=$(pwd)
cd $(dirname "$0")

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color


DIFF_EXAM="vim -d"
#DIFF_EXAM="diff -d"
FILES=./*.in
CPATH=../po-uuilib.jar:../project/mmt-core/mmt-core.jar:../project/mmt-app/mmt-app.jar
#CPATH=tmp/po-uuilib.jar:tmp/project/mmt-core/mmt-core.jar:tmp/project/mmt-app/mmt-app.jar

one_file_test(){
    
    if [ -r "$1" ]; then return 2; fi

    local f="$1"
    local status=1;

    echo "\n=== $f Test ==="

    if [ -r "$f".import ]; then
        java ${CPATH:+ -cp "$CPATH"} -Dimport="$f".import -Din="$f".in -Dout="$f".outhyp mmt.app.App
    else
        java ${CPATH:+ -cp "$CPATH"} -Din="$f".in -Dout="$f".outhyp mmt.app.App
    fi

    # diff if successful
    if [ $? -eq 0 ]; then
      diff "$f".outhyp expected/"$f".out
      if [ $? -eq 0 ]; then
        status=0
        echo "Test ${GREEN}PASSED ${NC}"
      else
        echo "Test ${RED}FAILED ${NC}(different)"
        if [ DIFF_EXAM ]; then
            $DIFF_EXAM "$f".outhyp expected/"$f".out
        fi
        read -n1 -r -p "Press any key to continue..." key

      fi
    else
      status=2
      echo "Test ${RED}FAILED ${NC}(aborted)"
      read -n1 -r -p "Press any key to continue..." key
    fi

    rm "$f".outhyp
    return $status

}

min_one_file_test(){

    if [ -r "$1" ]; then return 2; fi

    local f="$1"
    local status=1

    echo "$f Test :"

    if [ -r "$f".import ]; then
        java ${CPATH:+ -cp "$CPATH"} -Dimport="$f".import -Din="$f".in -Dout="$f".outhyp mmt.app.App
    else
        java ${CPATH:+ -cp "$CPATH"} -Din="$f".in -Dout="$f".outhyp mmt.app.App
    fi


    # diff if successful
    if [ $? -eq 0 ]; then
      diff "$f".outhyp expected/"$f".out > /dev/null
      if [ $? -eq 0 ]; then
        status=0
        echo "Test ${GREEN}PASSED ${NC}"
      else
        echo "Test ${RED}FAILED ${NC}(different)"
      fi
    else
      status=2
      echo "Test ${RED}FAILED ${NC}(aborted)"
    fi

    rm "$f".outhyp
    return $status
}

test_all_files(){

   local passed=0
   local failed=0
   local error=0
   local total=0
   local ret=0

   for f in $FILES
   do 
       # extract the main name
       tmp=${f#./*}
       f=${tmp%.in}

       # run the actual test
       ${1:-one_file_test} "$f"
       ret=$?

       # increase counters
       total=$((total+1))
       if   [ $ret -eq 0 ]; then passed=$((passed+1));
       elif [ $ret -eq 1 ]; then failed=$((failed+1));
       elif [ $ret -eq 2 ]; then error=$((error+1));
       fi

   done

   printf '\nTotal: %d\nPassed: %d\nFailed: %d\nError in test: %d\n' $total $passed $failed $error

}

cleanup(){
    # Remove saved sessions from project
    rm -f ./saved??
}

TEST="min_one_file_test"


if [ "$1" ]; then TEST="one_file_test"
fi

if [ "$3" ]; then FILE="A-$2-$3-M-ok"
fi

if [ "$FILE" ]; then $TEST $FILE
else test_all_files $TEST
fi

cleanup

cd "$ORIG_DIR"
