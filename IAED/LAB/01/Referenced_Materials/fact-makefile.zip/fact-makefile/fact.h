/*
 * fact.h -- definicoes e declaracoes globais para o programa fact
 */
#ifndef _FACT_
#define _FACT_

int factorial(int n);

#endif
