
#include <stdio.h>
#include "fact.h"

#define NUM 5

int n;

int main()
{
    n = NUM;

    printf("%d\n", factorial(n));

    return 0;
}
