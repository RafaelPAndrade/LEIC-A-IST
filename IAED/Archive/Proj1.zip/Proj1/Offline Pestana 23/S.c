/*********************************************************\
|IAED 2016/17 Projeto 1 - forum de mensagens
|Ficheiro: S.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

#include <stdio.h>
#include <string.h>
#include "header.c"

void funcao_S(const Mensagem forum[],const int n_mensagens){
	int index_aux[n_mensagens];
	int i;

	for(i=0; i<n_mensagens; i++)
		index_aux[i]=i;

	bubble(index_aux,0,n_mensagens-1,forum);

	printf("*SORTED MESSAGES:%d\n",n_mensagens);

	for(i=0; i<n_mensagens; i++)
		printf("%d:%s\n", forum[index_aux[i]].user_id, forum[index_aux[i]].frase);
}

int cmp(Mensagem msg1,Mensagem msg2)
{
	//Retorna positivo se msg1 for maior que msg2
	int res;

	res=strcmp(msg1.frase,msg2.frase);
	if(!res)
		res=msg1.user_id-msg2.user_id;
	return res;
}

void bubble(int index_aux[], int l, int r,const Mensagem forum[])
{
	int i,j,aux;
	for(i=l;i<r;i++)
		for(j=l;j<r-i;j++)
			if(cmp(forum[index_aux[j]],forum[index_aux[j+1]])>0)
			{
				aux=index_aux[j];
				index_aux[j]=index_aux[j+1];
				index_aux[j+1]=aux;
			}
}
