/*********************************************************\
|IAED 2016/17 Projeto 1 - forum de mensagens
|Ficheiro: C.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

#include <stdio.h>
#include "header.c"

void funcao_C(const int forum, const int n_mensagens){

	char frase[MAX_LEN_FRASE], c;
	int n_ocorrencias=0, len_palavra=0, i;

	//Elimina o espaco em branco
	getchar();

	while ( (c=getchar())!='\n' && c!=EOF && c!=' ' && c!='.' && c!=';' && c!=',' && c!='\t' && c!='\0' && i<MAX_LEN_FRASE )
		palavra[i++]=c;

	palavra[i]='\0';


	for (i=0; i<n_mensagens; ++i)
		n_ocorrencias+=compara(forum[i].palavra, palavra, len_palavra);

	printf("*WORD %s:%d\n",palavra, n_ocorrencias);

}


int compara(const char frase[], const char palavra[], const int len_palavra){

	int i=0, j, n_ocorrencias_frase=0;

	while ( frase[i]!='\0'){

	if (frase[i]==palavra[j]){
		++j;
		++i;
	}


	else {
		j=0;
		i=proxima_palavra(frase, i);
	}


	if (j==len_palavra)
		if ( frase[i+1]==EOF || frase[i+1]==' ' || frase[i+1]=='.' || frase[i+1]==';' || frase[i+1]==',' || frase[i+1]=='\t')
				++n_ocorrencias_frase;
		else
			j=0;



	}




}




int proxima_palavra(const char frase[], const int index){


	int i=index;

	while ( frase[i]!=EOF && frase[i]!=' ' && frase[i]!='.' && frase[i]!=';' && frase[i]!=',' && frase[i]!='\t' && frase[i]!='\0')
		i++;

	while (frase[i]==' ' || frase[i]=='.' || frase[i]==';' || frase[i]==',' || frase[i]=='\t' || frase[i]=='\0')
		i++;


	return i;
}



