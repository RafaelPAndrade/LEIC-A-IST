#!/bin/bash  

./run.sh $1 *.in