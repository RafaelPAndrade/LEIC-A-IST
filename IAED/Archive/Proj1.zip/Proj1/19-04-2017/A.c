/*********************************************************\
|IAED 2016/17 Projeto 1 - forum de mensagens
|Ficheiro: A.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

#include <string.h>
#include "header.c"


/****************************************************************************\
 Funcao funcao_A (Adicionar uma nova mensagem): de acordo com os argumentos que recebe,
  regista a mensagem no forum (lista forum[]), faz um incremento de um valor ao numero
  de mensagens (lista mensagens_por_user[]) do utilizador (user_id) e altera os
  valores do maior comprimento da frase (referente ao ponteiro ptr_comp) e do numero
  de mensagens do utilizador mais activo (referente ao ponteiro ptr_act)

	|Argumentos:
	|	-forum: lista de Mensagens (vide header.c)
	|	-msg: frase a adicionar a <forum>
	|	-user_id: utilizador que postou <msg>
	|	-n_mensagens: numero de mensagens no forum
	|	-mensagens_por_user: contador de mensagens de todos os users
	|	-ptr_comp: ponteiro para o numero de chars da maior frase no <forum>
	|	-ptr_comp: ponteiro para o numero de posts do user mais ativo de <forum>
	|
	|
	|Output:
	|	-void
	|
	|Return:
	|	-void
	|
\*****************************************************************************/

void funcao_A(Mensagem forum[], const char msg[], const int user_id, int n_mensagem, int mensagens_por_user[], int *ptr_comp, int *ptr_act) {

	forum[n_mensagem].user_id=user_id;
	mensagens_por_user[user_id]++;

	if(strlen(msg)> *ptr_comp)
		*ptr_comp=strlen(msg);

	if(mensagens_por_user[user_id]>*ptr_act)
		*ptr_act=mensagens_por_user[user_id];

	int i;
	for(i=0;msg[i]!='\0';i++)
		forum[n_mensagem].frase[i]=msg[i];
	forum[n_mensagem].frase[i]='\0';
}
