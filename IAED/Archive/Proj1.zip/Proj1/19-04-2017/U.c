/*********************************************************\
|IAED 2016/17 Projeto 1 - forum de mensagens
|Ficheiro: U.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

# include <stdio.h>
# include "header.c"

/**************************************************************************\
 Funcao funcao_U (Listar mensagens de um certo utilizador): ao receber os argumentos
  forum, n_mensagens e user (numero do utilizador) imprime as mensagens referentes
  ao utilizador em questao
  
	|Argumentos:
	|	-forum: lista de Mensagens (vide header.c)
	|	-n_mensagens: numero de mensagens no forum
	|	-user: numero do utilizador a procurar as mensagens
	|
	|Output:
	|	-Todas as frases do utilizador no <forum>
	|
	|Return:
	|	-void
	|
\**************************************************************************/

void funcao_U(const Mensagem forum[], const int n_mensagens, const int user){

	int i;

	printf("*MESSAGES FROM USER:%d\n", user);


	for (i=0; i<n_mensagens; ++i)
		if (forum[i].user_id==user)
			printf("%s\n", forum[i].frase);

}
