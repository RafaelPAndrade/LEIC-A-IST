/*********************************************************\
|IAED Projeto 1 - forum de mensagens
|2016/17
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

#include <stdio.h>
#include <string.h>
#include "header.c"


Comando Interpretador(void) {

	Comando instrucao;
	int c, flag=0, i=0;


	while((c=getchar())!='\n' && c!=EOF)
	{

		if (c==' ' && flag<2){
			++flag;
		}

		else if (flag==0){
			instrucao.op=c;
		}

		else if (flag==1){
			scanf("%d", &instrucao.numero_user);
			++flag;
		}

		else if (i<= MAX_LEN_FRASE){
			instrucao.msg[i++]=c;
		}
	}

	instrucao.msg[i]='\0';

	return instrucao;
}
