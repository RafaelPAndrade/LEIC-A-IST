/*********************************************************\
|IAED Projeto 1 - forum de mensagens
|2016/17
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

//O numero maximo de caracteres numa frase
# define MAX_LEN_FRASE 140

//O numero maximo de utilizadores
# define MAX_USERS 1000

//O numero maximo de mensagens no forum
# define MAX_MSGS 10000

typedef struct mensagem{
	//cada entrada tem o id de utilizador e uma frase
	int user_id;
	char frase[MAX_LEN_FRASE+1];
}	Mensagem;


typedef struct cmd{
	char op;
	int numero_user;
	char msg[MAX_LEN_FRASE+1];
} Comando;


//Forum: conjunto de mensagens
//Ex:
//Mensagem forum[MAX_MSGS];



Comando Interpretador(void);

void Adicionar(Mensagem forum[], const char msg[], const int user_id, int n_mensagem, int mensagens_por_user[], int *a,
	int *b);


void Lista_mensagens(const Mensagem [], const int);

void User_lista_mensagens(const Mensagem forum[], const int n_mensagens, const int user);

void Lista_mensagens_longas(const Mensagem forum[], const int n_mensagens, const int comprimento_max);

void User_lista_ativos(const int mensagens_por_user[MAX_USERS], const int n_mensagens_mais_ativo);

