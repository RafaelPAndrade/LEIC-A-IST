/*********************************************************\
|IAED Projeto 1 - forum de mensagens
|2016/17
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

# include <stdio.h>
# include "header.c"


void User_lista_ativos(const int mensagens_por_user[MAX_USERS], const int n_mensagens_mais_ativo){
	/*********************************************************\
	|Argumentos:
	|	-mensagens_por_user: contador de mensagens de cada user
	|	-n_mensagens_mais_ativo: n. de mensagens
	|
	|Output:
	|	- User com mais mensagens postadas no forum
	|
	|Return:
	|	-void
	|
	\********************************************************/

	int i;

	for(i=0; i<MAX_USERS; ++i)
		if (mensagens_por_user[i]==n_mensagens_mais_ativo)
			printf("*MOST ACTIVE USER:%d:%d\n", i, n_mensagens_mais_ativo);
}
