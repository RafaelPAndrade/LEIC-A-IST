/*********************************************************\
|IAED 2016/17 Projeto 1 - forum de mensagens
|Ficheiro: main.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

#include <stdio.h>
#include "header.c"

int main(){


	//Inicializacao de variaveis

	//Forum: lista de mensagens (vide header.c)
	Mensagem forum[MAX_MSGS]={};
	//numero de mensagens no forum
	int n_mensagens=0;

	//cmd: tipo comando (vide header.c)
	Comando cmd;
	cmd.op=0;

	//Inteiro que guarda o comprimento da maior frase + ponteiro
	int maior_comprimento_frase=0, *ptr_comp;
	ptr_comp=&maior_comprimento_frase;

	//Contador de mensagens que cada user postou no <forum>
	int mensagens_por_user[MAX_USERS]={};

	//Inteiro que guarda o numero de posts do user mais ativo + ponteiro
	int n_mensagens_user_mais_ativo=0, *ptr_act;
	ptr_act=&n_mensagens_user_mais_ativo;


	while(cmd.op!='X')
	{
		//1o Passo: ler o comando de stdin
		cmd=Interpretador();
		switch(cmd.op)
		{
			case 'A':
				//Adiciona uma mensagem ao forum (vide A.c)
				funcao_A(forum,cmd.msg,cmd.numero_user, n_mensagens++, mensagens_por_user, ptr_comp, ptr_act);
				break;
			case 'L':
				//Lista todas as mensagens de forum (vide L.c)
				funcao_L(forum, n_mensagens);
				break;
			case 'U':
				//Lista todas mensagens de um user especifico (vide U.c)
				User_lista_mensagens(forum, n_mensagens, cmd.numero_user);
				break;
			case 'O':
				//Escreve a mensagem mais longa do forum (vide O.c)
				funcao_O(forum, n_mensagens, maior_comprimento_frase);
				break;
			case 'T':
				//Apresenta o utilizador mais ativo do forum (vide T.c)
				User_lista_ativos(mensagens_por_user, n_mensagens_user_mais_ativo);
				break;
			case 'S':
				//Apresenta as frase do forum por ordem alfabetica
				//NAO IMPLEMENTADO!
				printf("%c %d %s",cmd.op,cmd.numero_user,cmd.msg);
				break;
			case 'C':
				//Imprime o numero de ocorrencias de determinada palavra
				//NAO IMPLEMENTADO!
				printf("%c %d %s",cmd.op,cmd.numero_user,cmd.msg);
				break;
		}
	}
	//Ao sair, apresenta o numero de mensagens do forum;
	printf("%d\n", n_mensagens);
	return 0;
}
