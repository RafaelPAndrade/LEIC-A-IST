/*********************************************************\
|IAED Projeto 1 - forum de mensagens
|2016/17
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

# include <stdio.h>
# include "header.c"


void User_lista_mensagens(const Mensagem forum[], const int n_mensagens, const int user){

	int i;

	printf("*MESSAGES FROM USER:%d\n", user);


	for (i=0; i<n_mensagens; ++i)
		if (forum[i].user_id==user)
			printf("%s\n", forum[i].frase);

}
