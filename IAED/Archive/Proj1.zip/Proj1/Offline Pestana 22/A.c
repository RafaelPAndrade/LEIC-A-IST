/*********************************************************\
|IAED 2016/17 Projeto 1 - forum de mensagens
|Ficheiro: A.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

#include <stdio.h>
#include <string.h>
#include "header.c"


/****************************************************************************\
 Funcao funcao_A (Adicionar uma nova mensagem):
    -Le o user e uma frase, adicionando-os ao forum
    -incrementa o numero de mensagens (lista mensagens_por_user[]) do utilizador (user_id)
    -altera o valor do maior comprimento da frase (referente ao ponteiro ptr_max_cmp_frase)
    -altera o numero de mensagens do utilizador mais activo (referente ao ponteiro ptr_act)

	|Argumentos:
	|	-forum: lista de Mensagens (vide header.c)
	|	-n_mensagens: numero de mensagens no forum
	|	-mensagens_por_user: contador de mensagens de todos os users
	|	-ptr_max_cmp_frase: ponteiro para o numero de chars da maior frase no <forum>
	|	-ptr_act: ponteiro para o numero de posts do user mais ativo de <forum>
	|
	|
	|Input:
	|	-msg: frase a adicionar a <forum>
	|	-user_id: utilizador que postou <msg>
	|
	|Output:
	|	-void
	|
	|Return:
	|	-void
	|
\*****************************************************************************/

void funcao_A(Mensagem forum[], int n_mensagem, int mensagens_por_user[], int *ptr_max_cmp_frase, int *ptr_act) {

	int i=0;
	char c;

	//Elimina o espaco em branco antes do user id
	getchar();

	//Le o user id
	scanf("%d", &forum[n_mensagem].user_id);

	//Elimina o espaco em branco antes da frase
	getchar();

	//Le a frase
	while ( (c=getchar())!='\n' && c!=EOF && i<MAX_LEN_FRASE )
		forum[n_mensagem].frase[i++]=c;

	forum[n_mensagem].frase[i]='\0';



	//Incrementa o contador de mensagens
	mensagens_por_user[forum[n_mensagem].user_id]++;

	//Ve se ha algo mais a mudar
	if(i> *ptr_max_cmp_frase)
		*ptr_max_cmp_frase=i;

	if ( mensagens_por_user[forum[n_mensagem].user_id]>*ptr_act )
		*ptr_act=mensagens_por_user[forum[n_mensagem].user_id]++;


}
