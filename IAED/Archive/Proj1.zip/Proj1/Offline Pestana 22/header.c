/*********************************************************\
|IAED 2016/17 Projeto 1 - forum de mensagens
|Ficheiro: header.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

//O numero maximo de caracteres numa frase
# define MAX_LEN_FRASE 140

//O numero maximo de utilizadores
# define MAX_USERS 1000

//O numero maximo de mensagens no forum
# define MAX_MSGS 10000

//Estrutura referente a mensagem(s) do forum onde e necessario registar o numero do utilizador (user_id)
// e a frase inserida pelo utilizador (frase)
typedef struct mensagem{
	//cada entrada tem o id de utilizador e uma frase
	int user_id;
	char frase[MAX_LEN_FRASE+1];
}	Mensagem;


/*********************************************************\
------------------------PROTOTIPOS------------------------
\*********************************************************/

void funcao_A(Mensagem forum[], int n_mensagem, int mensagens_por_user[], int *ptr_max_cmp_frase, int *ptr_act);

void funcao_L(const Mensagem forum[], const int n_mensagens);

void funcao_U(const Mensagem forum[], const int n_mensagens, const int mensagens_por_user[]);

void funcao_O(const Mensagem forum[], const int n_mensagens, const int max_cmp_frase);

void funcao_T(const int mensagens_por_user[MAX_USERS], const int n_mensagens_mais_ativo);

void funcao_S(const Mensagem forum[],const int n_mensagens);
int cmp(Mensagem msg1,Mensagem msg2);
void bubble(int index_aux[], int l, int r,const Mensagem forum[]);
