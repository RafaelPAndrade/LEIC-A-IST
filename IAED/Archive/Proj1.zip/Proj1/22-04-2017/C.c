	/*********************************************************\
|IAED 2016/17 Projeto 1 - forum de mensagens
|Ficheiro: C.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

#include <stdio.h>
#include <string.h>
#include "header.c"

/****************************************************************************\
	|Argumentos:
	|	-forum: lista de Mensagens (vide header.c)
	|	-n_mensagens: numero de mensagens no forum
	|
	|Output:
	|	-Numero de ocurrencias da palavra no <forum>
	|
	|Return:
	|	-void
	|
\****************************************************************************/

void funcao_C(const Mensagem forum[],const int n_mensagens)
{
	int numero_occ=0,i,c,p=0;
	char palavra[MAX_LEN_FRASE];

	//Elimina o espaco em branco antes da palavra
	getchar();

	//Le a palavra
	while ( (c=getchar())!='\n' && c!=EOF)
		palavra[p++]=c;
	palavra[p]='\0';

	for(i=0;i<n_mensagens;i++)
		numero_occ+=compara(forum[i].frase,palavra);
	printf("*WORD %s:%d\n",palavra,numero_occ);
}

int compara(const char frase[], const char palavra[])
{
	int i,j=0,occ=0,flag=1;
	for(i=0;i<=strlen(frase);i++)
	{
		if(frase[i]==palavra[j] && (frase[i]!='\0' || palavra[j]!='\0') && flag==1)
		{
			j++;
		}else if(frase[i]==';' || frase[i]==',' || frase[i]==' ' || frase[i]=='\t' || frase[i]=='\n' || frase[i]=='.' || frase[i]=='\0')
		{
			occ=(j==strlen(palavra))? occ+1 : occ;
			j=0;
			flag=1;
		}else{
			j=flag=0;
		}
	}
	return occ;
}