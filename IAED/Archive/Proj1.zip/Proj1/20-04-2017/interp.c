/*********************************************************\
|IAED 2016/17 Projeto 1 - forum de mensagens
|Ficheiro: interp.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

#include <stdio.h>
#include <string.h>
#include "header.c"

/****************************************************************************\
	|Argumentos:
	|	-void
	|
	|Output:
	|	-void
	|
	|Return:
	|	-str: variavel do tipo Comando (vide header.c)
	|
\****************************************************************************/

Comando Interpretador()
{
	Comando str;
	int c,i=0,flag=0;

	scanf("%c",&str.op);
	while((c=getchar())!='\n')
	{
		if(c==' ' && flag==0){
			scanf("%d",&str.numero_user);
			flag=1;
		}else if(c==' ' && flag==1)
			flag=2;
		else if(flag==2 && i<= MAX_LEN_FRASE)
			str.msg[i++]=c;
		/*if(c==' ' && n<2){
			n++;
		}else if(c>='0' && c<='9' && n==1){
			numero=numero*10+(c-48);

		}else
			str.msg[i++]=c;*/
	}
	str.msg[i]='\0';
	return str;
}