/*********************************************************\
|IAED 2016/17 Projeto 1 - forum de mensagens
|Ficheiro: S.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

#include <stdio.h>
#include <string.h>
#include "header.c"

void funcao_S(const Mensagem forum[],const int n_mensagens){
	int index_aux[n_mensagens];
	int i;

	for(i=0; i<n_mensagens; i++)
		index_aux[i]=i;

	heapsort(index_aux,0,n_mensagens-1,forum);

	printf("*SORTED MESSAGES:%d\n",n_mensagens);

	for(i=0; i<n_mensagens; i++)
		printf("%d:%s\n", forum[index_aux[i]].user_id, forum[index_aux[i]].frase);
}

int cmp(Mensagem msg1,Mensagem msg2)
{
	//Retorna positivo se msg1 for maior que msg2
	int res;

	res=strcmp(msg1.frase,msg2.frase);
	if(!res)
		res=msg1.user_id-msg2.user_id;
	return res;
}

void heapsort(int index_aux[], int l, int r,const Mensagem forum[])
{
	int aux;
	buildheap(index_aux,l,r,forum);
	while (r-l > 0) {
		aux=index_aux[l];
		index_aux[l]=index_aux[r];
		index_aux[r]=aux;
		fixDown(index_aux, l, --r, l,forum);
	}
}

int parent(int k) {
	return ((k+1)/2)-1;
}

int left(int k) {
	return 2*k+1;
}

int right(int k) {
	return 2*(k+1);
}

void buildheap(int index_aux[], int l, int r,const Mensagem forum[]){
	int k, heapsize = r-l+1;
	for (k = heapsize/2-1; k >= l; k--)
		fixDown(index_aux, l, r, l+k,forum);
}

void fixDown(int index_aux[], int l, int r, int k,const Mensagem forum[])
{
	int ileft, iright, largest=k,aux;

	ileft=l+left(k-l);
	iright=l+right(k-l);

	if (ileft<=r && cmp(forum[index_aux[ileft]],forum[index_aux[largest]])>0)
		largest=ileft;

	if (iright<=r && cmp(forum[index_aux[iright]],forum[index_aux[largest]])>0)
		largest=iright;

	if (largest!=k){
		aux=index_aux[k];
		index_aux[k]=index_aux[largest];
		index_aux[largest]=aux;
		fixDown(index_aux, l, r, largest,forum);
	}
}