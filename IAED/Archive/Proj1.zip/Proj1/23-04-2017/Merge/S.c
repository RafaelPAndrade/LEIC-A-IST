/*********************************************************\
|IAED 2016/17 Projeto 1 - forum de mensagens
|Ficheiro: S.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*********************************************************/

#include <stdio.h>
#include <string.h>
#include "header.c"

void funcao_S(const Mensagem forum[],const int n_mensagens){
	int index_aux[n_mensagens];
	int i;

	for(i=0; i<n_mensagens; i++)
		index_aux[i]=i;

	mergesort(index_aux, 0, n_mensagens-1, forum);

	printf("*SORTED MESSAGES:%d\n",n_mensagens);

	for(i=0; i<n_mensagens; i++)
		printf("%d:%s\n", forum[index_aux[i]].user_id, forum[index_aux[i]].frase);
}

int cmp(Mensagem msg1,Mensagem msg2)
{
	//Retorna positivo se msg1 tiver alfabeticamente abaixo de msg2
	int res;

	res=strcmp(msg1.frase,msg2.frase);
	if(!res)
		res=msg1.user_id-msg2.user_id;
	return res>0;
}



void mergesort(int index_aux[], int l, int r, const Mensagem forum[])
{

	int m=(r+l)/2;
	if (r<=l) return;
	mergesort(index_aux, l, m, forum);
	mergesort(index_aux, m+1, r, forum);
	merge(index_aux, l, m, r, forum);
}


int aux[MAX_MSGS];
void merge(int index_aux[], int l, int m, int r, const Mensagem forum[]){

	int i, j, k;
	//copia de l a m, para o aux;
	for (i=m+1; i>l; --i)
		aux[i-1]=index_aux[i-1];
	for (j=m; j < r; ++j)
		aux[r+m-j]=index_aux[j+1];
	for (k=l; k<=r; ++k)
		if ( cmp(forum[aux[i]], forum[aux[j]] ) )
			index_aux[k]=aux[j--];
		else
			index_aux[k]=aux[i++];
}

