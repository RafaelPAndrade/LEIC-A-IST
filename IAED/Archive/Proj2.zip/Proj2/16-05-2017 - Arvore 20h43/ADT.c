/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: ADT.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

# include "ADT.h"

//Funcoes auxiliares
link NewNode(Item a, link l, link r);
link UpdateTree(link root, Item a);
void TraverseSorted(link root, void (*func)(Item));
link max(link root);
link DeleteNode(link root, Key k, void (*delete_func)(Item));
link DeleteTree(link root);


link NewNode(Item a, link l, link r){

	link res = (link) malloc(sizeof(struct node));
	res->item = a;
	res->left = l;
	res->right = r;
	n_chaves_dif+=1;
	return res;
}


link UpdateTree(link root, Item a){
//Se ja existir um Item com chave igual, junta as unidades;

	if (root==NULL){
		ValidItem(a);
		return NewNode(a, NULL, NULL);
		}
	if ( eq( key(a), key(root->item) ) )
		{
			UpdateItem(root->item, a->unidades);
			freeItem(a);
			return root;
		}
	else if ( less( key(a), key(root->item) ) )
		root->left = UpdateTree(root->left, a);
	else
		root->right = UpdateTree(root->right, a);
	return root;
}

void TraverseSorted(link root, void (*func)(Item)){

	if (root==NULL)
		return;
	TraverseSorted(root->left, func);
	func(root->item);
	TraverseSorted(root->right, func);
}


link MaxTree(link root) {

	if (root==NULL || root->right==NULL) return root;
	else return MaxTree(root->right);
}


link DeleteNode(link root, Key k, void (*delete_func)(Item)) {
	link aux;
	if (root==NULL) return root;
	else if (less(k, key(root->item))) root->left = DeleteNode(root->left, k, delete_func);
	else if (less(key(root->item), k)) root->right = DeleteNode(root->right, k, delete_func);
	else{
		if (root->left !=NULL && root->right !=NULL ) { /*caso 3*/
			aux=MaxTree(root->left);
			{Item x; x=root->item; root->item=aux->item; aux->item=x;}
			root->left=DeleteNode(root->left, key(aux->item), delete_func);
		}
		else { /*casos 1 e 2*/
			aux=root;
			if ( root->left == NULL && root->right == NULL ) root=NULL;
			else if (root->left==NULL) root=root->right;
			else root=root->left;
			delete_func(aux->item);
			free(aux);
			n_chaves_dif-=1;
		}
	}
	return root;
}


link DeleteTree(link root) {

	if (root==NULL) return root;
	root->left = DeleteTree(root->left);
	root->right = DeleteTree(root->right);
	return DeleteNode(root, key(root->item), freeItem);
}


void Init(link * root){

	*root = NULL;
}

void Insert(link * root, Item a){

	*root = UpdateTree(*root, a);
}

void Delete(link * root, Key k){

	*root = DeleteNode(*root, k, freeItem);
}


Item Search(link root, Key a){

	if (root==NULL)
		return NULL;
	if ( eq( key(root->item), a) )
		return root->item;
	else if ( less( key(root->item), a) )
		return Search(root->left, a);
	else
		return Search(root->right, a);
}

void ListNodes(link root){

	TraverseSorted(root, ShowItem);

}


void FreeAll(link * root){

	*root = DeleteTree(*root);

}

