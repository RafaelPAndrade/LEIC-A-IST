/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: ADT.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

# include "ADT.h"

//Funcoes auxiliares
link NewNode(Item a, link l, link r);
link UpdateTree(link root, Item a);
void TraverseSorted(link root, void (*func)(Item));

link NewNode(Item a, link l, link r){

	link res = (link) malloc(sizeof(struct node));
	res->item = a;
	res->left = l;
	res->right = r;
	return res;
}


link UpdateTree(link root, Item a){
//Se ja existir um Item com chave igual, junta as unidades;

	if (root==NULL)
		return NewNode(a, NULL, NULL);
	if ( eq( key(a), key(root->item) ) )
		root->item = UpdateItem(root->item, a->unidades);
	else if ( less( key(a), key(root->item) ) )
		root->left = UpdateTree(root->left, a);
	else
		root->right = UpdateTree(root->right, a);
	return root;
}

void TraverseSorted(link root, void (*func)(Item)){

	if (root==NULL)
		return;
	TraverseSorted(root->left, func);
	func(root->item);
	TraverseSorted(root->right, func);
}




void Init(link * root){

	*root = NULL;
}

void Insert(link * root, Item a){

	*root = UpdateTree(*root, a);
}

Item Search(link root, Key a){

	if (root==NULL)
		return NULL;
	if ( eq( key(root->item), a) )
		return root->item;
	else if ( less( key(root->item), a) )
		return Search(root->left, a);
	else
		return Search(root->right, a);
}

void ListNodes(link root){

	TraverseSorted(root, ShowItem);

}



