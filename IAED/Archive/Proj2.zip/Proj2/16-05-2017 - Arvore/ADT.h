/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: ADT.h
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

/*
Estrutura escolhida: arvore
*/

# ifndef _ADT_
# define _ADT_

# include "Item.h"

typedef struct node * link;

struct node {
	Item item;
	link left;
	link right;
};


/**************************************\
|Prototipos
\**************************************/

void Init(link * root);
void Insert(link * root, Item a);
Item Search(link, Key);
void ListNodes(link root);

# endif
