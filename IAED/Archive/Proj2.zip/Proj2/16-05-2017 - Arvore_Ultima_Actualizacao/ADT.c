/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: ADT.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

# include "ADT.h"

//Funcoes auxiliares
link NewNode(Item a, link l, link r);
link UpdateTree(link root, Item a);
void TraverseSorted(link root, void (*func)(Item));
link max(link root);
link delete(link root, Key k);

link NewNode(Item a, link l, link r){

	link res = (link) malloc(sizeof(struct node));
	res->item = a;
	res->left = l;
	res->right = r;
	return res;
}


link UpdateTree(link root, Item a){
//Se ja existir um Item com chave igual, junta as unidades;

	if (root==NULL)
		return NewNode(a, NULL, NULL);
	if ( eq( key(a), key(root->item) ) )
		root->item = UpdateItem(root->item, a->unidades);
	else if ( less( key(a), key(root->item) ) )
		root->left = UpdateTree(root->left, a);
	else
		root->right = UpdateTree(root->right, a);
	return root;
}

void TraverseSorted(link root, void (*func)(Item)){

	if (root==NULL)
		return;
	TraverseSorted(root->left, func);
	func(root->item);
	TraverseSorted(root->right, func);
}




void Init(link * root){

	*root = NULL;
}

void Insert(link * root, Item a){

	*root = UpdateTree(*root, a);
}

Item Search(link root, Key a){

	if (root==NULL)
		return NULL;
	if ( eq( key(root->item), a) )
		return root->item;
	else if ( less( key(root->item), a) )
		return Search(root->left, a);
	else
		return Search(root->right, a);
}

void ListNodes(link root){

	TraverseSorted(root, ShowItem);

}

link max(link root) {

	if (root==NULL || root->right==NULL) return root;
	else return max(root->right);
}

link delete(link root, Key k) {
	link aux ;
	if (root==NULL) return root;
	else if (less(k, key(root->item))) root->left=delete(root->left,k);
	else if (less(key(root->item), k)) root->right=delete(root->right,k);
	else{
		if (root->left !=NULL && root->right !=NULL ) { /*caso 3*/
			aux=max(root->left);
			{Item x; x=root->item; root->item=aux->item; aux->item=x;}
			root->left=delete(root->left, key(aux->item));
		}
		else { /*casos 1 e 2*/
			aux=root;
			if ( root->left == NULL && root->right == NULL ) root=NULL;
			else if (root->left==NULL) root=root->right;
			else root=root->left;
			deleteItem(aux->item);
			free(aux);
		}
	}
	return root;
}

link freeADT(link root){

	if (root==NULL) return root;
	root->left=freeADT(root->left);
	root->right=freeADT(root->right);
	return delete(root,key(root->item));
}
