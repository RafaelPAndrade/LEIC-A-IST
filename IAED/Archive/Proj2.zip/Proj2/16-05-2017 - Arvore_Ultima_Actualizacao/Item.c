/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: Item.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

# include "Item.h"

Item NewItem(unsigned new_chave, int new_unidades){

	Item res= (Item) malloc( sizeof(struct produto) );
	res->chave= new_chave;
	res->unidades= new_unidades;

	return res;
}

void ShowItem(Item a){

	printf("%.8x %d\n", a->chave, a->unidades);
}

void freeItem(Item a){

	free(a);
}

Item UpdateItem(Item a, int variacao){

	int aux = a->unidades+variacao;
	a->unidades = (aux > 0) ? aux : 0;

	return a;
}

void deleteItem(Item a){

	free(a);
}
