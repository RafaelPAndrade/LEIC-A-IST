/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: header.h
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include <stdio.h>

typedef struct produto *link;

struct produto{
	unsigned int chave;
	int unidades;
	link next;
};


/*****************************************************************\
----------------------------PROTOTIPOS-----------------------------
\*****************************************************************/

//funcao_a();

//funcao_l();

//funcao_m();

//funcao_r();