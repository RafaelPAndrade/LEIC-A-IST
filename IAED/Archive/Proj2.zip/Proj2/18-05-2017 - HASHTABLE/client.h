/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: client.h
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

# include "ADT.h"

void funcao_a(link armazem[DIM_TABLE]) {

	Key chave_input;
	int unidades_input;
	link *previous;
	link aux;

	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);
	//Para capturar o espaco que precede
	getchar();
	scanf("%d",&unidades_input);

	previous=Search(armazem, &chave_input);

	if ((*previous)==NULL || less(chave_input,key((*previous)->produto))){

		aux=*previous;
		Insert(previous, NewItem(chave_input, unidades_input));
		(*previous)->next=aux;

		n_chaves_dif+=1;
		if  ( max_unidades > -1) {
			if  (unidades_input > max_unidades ||
    			( unidades_input == max_unidades && less(chave_input, max_unidades_chave)) ){
    			max_unidades = unidades_input;
    			max_unidades_chave = chave_input;
			}
		}
	}
	else if (eq((*previous)->produto->chave,chave_input)){

		Update(previous,&unidades_input);

		if (max_unidades > -1) {
			if ( eq (chave_input, max_unidades_chave) ){
				if (unidades_input < 0 ) {
					max_unidades = -1;
				}
				else{
					max_unidades += unidades_input;
				}
			}

			else if ( (*previous)->produto->unidades > max_unidades ||
					( (*previous)->produto->unidades == max_unidades && less(key((*previous)->produto), max_unidades_chave))) {
				max_unidades = (*previous)->produto->unidades;
				max_unidades_chave = key((*previous)->produto);
			}
		}
	}

}

void funcao_r(link armazem[DIM_TABLE]) {

	Key chave_input;

	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);
    
    if ( chave_input == max_unidades_chave )
		max_unidades = -1;

	if(Remove(armazem,&chave_input)==1)
		n_chaves_dif-=1;
}
