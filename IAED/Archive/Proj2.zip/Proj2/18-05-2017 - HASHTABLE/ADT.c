/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: ADT.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

# include "ADT.h"

int hash(const Key * chave){

	return *chave / DIVISOR_HASH;
}

link * Search(link armazem[DIM_TABLE], const Key * chave)
{
	link * aux = armazem + hash(chave);

	//Trocar a ordem: ver se o proximo(next) e NULL antes de procurar a chave...
	for( ; (*aux) != NULL && key((*aux)->produto) < *chave; aux=&( (*aux)->next));

	return aux;
}

link * Init(void)
{
	link * armazem=(link*)calloc(DIM_TABLE,sizeof(link));
	return armazem;
}

void Insert(link * previous, Item prod)
{
	link aux=*previous;
	*previous=(link)malloc(sizeof(struct node));
	(*previous)->produto=prod;
	(*previous)->next=aux;
}

void Update(link * node, int * variacao_produto)
{
	(*node)->produto=UpdateItem((*node)->produto, variacao_produto);
}

int Remove(link armazem[DIM_TABLE], Key * chave)
{
	link aux;
	link * candidato_apagar=Search(armazem, chave);

	if((*candidato_apagar)!=NULL && eq(key((*candidato_apagar)->produto),*chave))
	{
		aux=*candidato_apagar;
		*candidato_apagar=aux->next;

		freeItem(aux->produto);
		free(aux);
		return 1;
	}
	return 0;
}

void PrintSorted(link armazem[DIM_TABLE])
{
	int i=0;
	link ptr;
	for(;i<DIM_TABLE;)
		for(ptr=armazem[i++];ptr!=NULL;ptr=ptr->next)
			ShowItem(ptr->produto);
}


void FreeADT(link armazem[DIM_TABLE])
{
	int i;
	link aux, next;
	for (i=0;i<DIM_TABLE;i++){
		aux=armazem[i];
		while (aux != NULL){
			next=aux->next;
			freeItem(aux->produto);
			free(aux);
			aux=next;
		}
	}
	free(armazem);
}

void ShowMax(link armazem[DIM_TABLE])
{
	if(n_chaves_dif!=0) {
		if (max_unidades == -1){
		int i=0;
		link pt;
		max_unidades_chave=0xFFFFFFFF;
			for(;i<DIM_TABLE;) {
				for(pt=armazem[i++];pt!=NULL;pt=pt->next) {
					if(pt->produto->unidades>max_unidades) {
						max_unidades_chave=pt->produto->chave;
						max_unidades=pt->produto->unidades;
					}
				}
			}
		}
		printf("%.8x %d\n", max_unidades_chave, max_unidades);
	}
}



