/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: client.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
# include "ADT.h"

void funcao_a(link * root);
void funcao_r(link * root);
void funcao_m(link root);

void funcao_a(link * root){

	Key chave_input;
	int unidades_input;

	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);
	//Para capturar o espaco que precede
	getchar();
	scanf("%d",&unidades_input);

	Item a=NewItem(chave_input, unidades_input);

	Insert(root, a);

}


void funcao_r(link * root){

	Key chave_input;

	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);

	Delete(root, chave_input);
}

void funcao_m(link root){

	if(n_chaves_dif!=0) {
		if (item_max_unidades == NULL) TraverseSorted(root, MaiorProduto);

		printf("%.8x %d\n", key(item_max_unidades), units(item_max_unidades));
	}
}
