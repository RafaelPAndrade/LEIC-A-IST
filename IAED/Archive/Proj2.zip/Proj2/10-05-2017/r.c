/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: r.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"

void funcao_r(link armazem[0x10], int * n_chaves_total, unsigned * max_unidades_chave, int * max_unidades)
{
	unsigned chave_input;
	link *previous, aux;

	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);

	previous=funcao_procura(armazem,chave_input);

	if((*previous)!=NULL && (*previous)->chave==chave_input)
	{
		aux=*previous;
		*previous=(*previous)->next;
		free(aux);

		*(n_chaves_total)=*(n_chaves_total)-1;
	}

	if(*max_unidades_chave==chave_input)
	{
		int i;
		link pt;
		*max_unidades_chave=0xFFFFFFFF;
		*max_unidades=0;
		printf("A imprimir...\n");
		for(i=0;i<16;i++)
			for(pt=armazem[i];pt!=NULL;pt=pt->next)
				if(pt->unidades>*max_unidades || ((pt->unidades==*max_unidades) && pt->chave<*max_unidades_chave))
				{
					*max_unidades_chave=pt->chave;
					*max_unidades=pt->unidades;
				}
	
	}

}
