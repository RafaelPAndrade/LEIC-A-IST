# include "header.h"

void free_Armazem(link armazem[0x10], int n_sublistas){

	link aux, next;

	for (n_sublistas--; n_sublistas>=0; --n_sublistas){
		aux=armazem[n_sublistas];
		printf("A limpar sublista %d\n", n_sublistas);
		while (aux != NULL){
			next=aux->next;
			free(aux);
			aux=next;
		}
	}
}
