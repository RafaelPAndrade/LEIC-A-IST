/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: a.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"

void funcao_a(link armazem[DIM_HASH_TABLE], int * n_chaves_total) {

	unsigned chave_input;
	int unidades_input;
	link *previous;
	link aux;


	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);
	//Para capturar o espaco que precede
	getchar();
	scanf("%d",&unidades_input);

	previous=funcao_procura(armazem, &chave_input);

	if ((*previous)==NULL || (*previous)->chave > chave_input){
		//Acontece sem elementos na lista
		aux=*previous;
		(*previous) = (link) malloc(sizeof(struct produto));
		(*previous)->chave= chave_input;
		(*previous)->unidades= (unidades_input > 0) ? unidades_input : 0;
		(*previous)->next= aux;
		*(n_chaves_total)=*(n_chaves_total)+1;
	}

	else if ((*previous)->chave == chave_input){
		//Acontece com um produto ja com a mesma chave_input
		(*previous)->unidades= ((*previous)->unidades + unidades_input > 0) ? (*previous)->unidades+unidades_input : 0;
	}
}
