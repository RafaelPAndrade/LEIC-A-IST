/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: procura.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"

unsigned hash(const unsigned * chave) {
	return *chave/HASH;
}

link * funcao_procura(link armazem[DIM_HASH_TABLE], const unsigned * chave)
{
	link * aux = armazem + hash(chave);
	//link * aux = &armazem[hash(chave)];

	//Trocar a ordem: ver se o proximo(next) e NULL antes de procurar a chave...
	for( ; (*aux) != NULL && (*aux)->chave < *chave; aux=&( (*aux)->next));

	return aux;
}

