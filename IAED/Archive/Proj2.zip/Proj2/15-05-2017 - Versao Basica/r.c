/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: r.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"

void funcao_r(link armazem[DIM_HASH_TABLE], int * n_chaves_total)
{
	unsigned chave_input;
	link *previous, aux;

	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);

	previous=funcao_procura(armazem,&chave_input);

	if((*previous)!=NULL && (*previous)->chave==chave_input)
	{
		aux=*previous;
		*previous=(*previous)->next;
		free(aux);

		*(n_chaves_total)=*(n_chaves_total)-1;
	}

}
