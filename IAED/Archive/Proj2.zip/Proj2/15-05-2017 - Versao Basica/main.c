/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: main.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"

int main()
{
	int n_chaves_dif=0;

	link armazem[DIM_HASH_TABLE] = { NULL };

	//Caractere que representa o comando a executar
	char op;

	do {
		op=getchar();
		switch(op)
		{
			case 'a':
				funcao_a(armazem, &n_chaves_dif);
				break;
			case 'l':
				funcao_l(armazem);
				break;
			case 'm':
				funcao_m(armazem, &n_chaves_dif);
				break;
			case 'r':
				funcao_r(armazem, &n_chaves_dif);
				break;
		}

	} while(op!='x');


	//Ao sair, apresenta o numero de chaves diferentes;
	printf("%d\n", n_chaves_dif);
	free_Armazem(armazem, DIM_HASH_TABLE);
	return 0;
}
