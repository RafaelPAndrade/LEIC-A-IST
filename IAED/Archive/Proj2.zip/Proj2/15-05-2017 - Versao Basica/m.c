/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: m.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"


void funcao_m(const link armazem[DIM_HASH_TABLE], const int * n_chaves_diff ){

	if(*n_chaves_diff!=0)
	{
		int i= 0;
		link pt;
		unsigned max_unidades_chave=CHAVE_MAX;
		int max_unidades=-1;
		for( ;i<DIM_HASH_TABLE; )
			for(pt=armazem[i++];pt!=NULL;pt=pt->next)
				if(pt->unidades>max_unidades)
				{
					max_unidades_chave=pt->chave;
					max_unidades=pt->unidades;
				}
		printf("%.8x %d\n", max_unidades_chave, max_unidades);
	}
}
