/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: main.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

# include "ADT.h"

void funcao_a(link armazem[DIM_TABLE]);
void funcao_r(link armazem[DIM_TABLE]);
void funcao_m(link armazem[DIM_TABLE]);

void funcao_a(link armazem[DIM_TABLE]) {

	Key chave_input;
	int unidades_input;

	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);
	//Para capturar o espaco que precede
	getchar();
	scanf("%d",&unidades_input);

	Insert(armazem, chave_input, unidades_input);

}

void funcao_r(link armazem[DIM_TABLE]) {

	Key chave_input;

	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);

	Delete(armazem, chave_input);
}


void funcao_m(link armazem[DIM_TABLE]) {

	if(n_chaves_dif!=0) {
		if (item_max_unidades == NULL) TraverseSorted(armazem, MaiorProduto);

		printf("%.8x %d\n", key(item_max_unidades), units(item_max_unidades));
	}
}



int main()
{
	link * armazem = NULL;
	Init(&armazem);

	char op;

	do {
		op=getchar();
		switch(op)
		{
			case 'a':
				funcao_a(armazem);
				break;
			case 'l':
				TraverseSorted(armazem, ShowItem);
				break;
			case 'm':
				funcao_m(armazem);
				break;
			case 'r':
				funcao_r(armazem);
				break;
		}

	} while(op!='x');


	//Ao sair, apresenta o numero de chaves diferentes;
	printf("%d\n", n_chaves_dif);
	FreeAll(armazem);

	return 0;
}


