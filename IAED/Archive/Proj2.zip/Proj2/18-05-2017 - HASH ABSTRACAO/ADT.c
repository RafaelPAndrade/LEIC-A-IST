/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: ADT.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

# include "ADT.h"

int hash(const Key chave);
link * searchNode(link armazem[DIM_TABLE], const Key chave);
void newNode(link * previous, Item prod);


int hash(const Key chave){

	return chave / DIVISOR_HASH;
}

link * searchNode(link armazem[DIM_TABLE], const Key chave) {

	link * res = armazem + hash(chave);
	for( ; (*res) != NULL && less(key((*res)->item), chave); res = &(*res)->next );

	return res;
}


void newNode(link * previous, Item prod) {
	link aux = *previous;
	*previous = (link) malloc(sizeof(struct node));
	(*previous)->item=prod;
	(*previous)->next=aux;
}



void Init(link ** armazem) {

	item_max_unidades = NULL;
	*armazem = (link*) calloc(DIM_TABLE, sizeof(link));
}


void Insert(link armazem[DIM_TABLE], Key chave, int unidades){

	link * previous;
	link aux;

	previous = searchNode(armazem, chave);

	if ( (*previous)==NULL || less(chave, key((*previous)->item)) ) {

		aux = *previous;
		newNode(previous, NewItem(chave, unidades));
 		(*previous)->next = aux;

		n_chaves_dif+=1;

		if  ( item_max_unidades != NULL) {
			if ( unidades > units(item_max_unidades) ||
    			 (unidades == units(item_max_unidades) && less(chave, key(item_max_unidades)) ) ){
				item_max_unidades = (*previous)->item;
			}
		}
	}

	else if ( eq(key((*previous)->item), chave) ){

		(*previous)->item = UpdateItem((*previous)->item, unidades);

		if ( item_max_unidades != NULL ) {
			if ( eq (chave, key(item_max_unidades)) ){
				if (unidades < 0 )
					item_max_unidades = NULL;
			}

			else if ( units((*previous)->item) > units(item_max_unidades) ||
					( units((*previous)->item) == units(item_max_unidades) && less(key((*previous)->item), key(item_max_unidades)) ) ) {
				item_max_unidades = (*previous)->item;
			}
		}
	}
}



void Delete(link armazem[DIM_TABLE], Key chave) {

	link aux;
	link * candidato_apagar = searchNode(armazem, chave);

	if ( eq(chave, key(item_max_unidades)) ){
		item_max_unidades = NULL;
	}


	if( (*candidato_apagar)!=NULL && eq(key((*candidato_apagar)->item), chave) ) {
		aux = *candidato_apagar;
		*candidato_apagar = aux->next;
		freeItem(aux->item);
		free(aux);
		n_chaves_dif-=1;
	}
}


void TraverseSorted(link armazem[DIM_TABLE] , void(*func)(Item)) {
	int i;
	link ptr;
	for( i=0; i<DIM_TABLE; ++i )
		for( ptr=armazem[i]; ptr!=NULL; ptr=ptr->next )
			func(ptr->item);
}

void MaiorProduto(Item a) {
	if ( units(a) > units(item_max_unidades) )
		item_max_unidades = a;
}


void FreeAll(link armazem[DIM_TABLE]) {
	int i;
	link aux, next;
	for ( i=0;i<DIM_TABLE;i++ ){
		aux=armazem[i];
		for( aux = armazem[i]; aux != NULL; aux=next ) {
			next=aux->next;
			freeItem(aux->item);
			free(aux);
		}
	}
	free(armazem);
}
