/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: a.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"

void funcao_a(link armazem[0x10], int * n_chaves_total ,unsigned * max_unidades_chave, int * max_unidades) {

	unsigned chave_input;
	int unidades_input;
	link previous;
	link aux;


	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);
	//Para capturar o espaco que precede
	getchar();
	scanf("%d",&unidades_input);

	previous=funcao_procura(armazem, chave_input);
	
	if (previous==NULL || previous->chave > chave_input){
		//Acontece sem elementos na lista
		printf("0 elementos, a por no primeiro....\n");

		aux = (link) malloc(sizeof(struct produto));
		aux->chave= chave_input;
		aux->unidades= (unidades_input > 0) ? unidades_input : 0;
		aux->next= previous;
		armazem[hash(chave_input)]=aux;
		*(n_chaves_total)=*(n_chaves_total)+1;
	}

	else if (previous->chave == chave_input){
		printf("Ja havia registo, a mudar quantidade\n");
		//Acontece com um produto ja com a mesma chave_input

		aux= previous;
		aux->unidades= (aux->unidades + unidades_input > 0) ? aux->unidades+unidades_input : 0;
	}

	else if (previous->next==NULL  || previous->next->chave!=chave_input){
		//Acontece com elementos ja na lista (ultimos elementos)
		printf("Ja havia elementos, chave %.8x unidades:%d\n", previous->chave, previous->unidades);

		aux = (link) malloc(sizeof(struct produto));
		aux->chave= chave_input;
		aux->unidades= (unidades_input > 0) ? unidades_input : 0;
		aux->next= previous->next;
		previous->next=aux;
		*(n_chaves_total)=*(n_chaves_total)+1;
	}

	else if (previous->next->chave == chave_input){
		printf("Ja havia registo, a mudar quantidade\n");
		//Acontece com um produto ja com a mesma chave_input

		aux=previous->next;
		aux->unidades= (aux->unidades + unidades_input > 0) ? aux->unidades+unidades_input : 0;
	}


	if ( aux->unidades > *(max_unidades) || ( aux->unidades == *(max_unidades) && aux->chave < *(max_unidades_chave) ) ){
		*(max_unidades)= aux->unidades;
		*(max_unidades_chave)= aux->chave;
	}
}
