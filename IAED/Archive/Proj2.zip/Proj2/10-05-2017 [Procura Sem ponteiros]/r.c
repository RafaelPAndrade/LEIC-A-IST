/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: r.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"

void funcao_r(link armazem[0x10], int * n_chaves_total)
{
	unsigned chave_input;
	link previous, aux;

	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);

	previous=funcao_procura(armazem,chave_input);

	if(previous->chave==chave_input)
	{
		aux=previous;
		armazem[hash(chave_input)]=previous->next;
		free(aux);

		*(n_chaves_total)=*(n_chaves_total)-1;
	}

	else if(previous->next->chave==chave_input)
	{
		aux=previous->next;
		previous->next=aux->next;
		free(aux);
		*(n_chaves_total)=*(n_chaves_total)-1;
	}

}