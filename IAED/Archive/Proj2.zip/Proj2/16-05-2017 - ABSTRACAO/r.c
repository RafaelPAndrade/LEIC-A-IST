/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: r.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
# include "ADT.h"

void funcao_r(link armazem[DIM_TABLE], int * n_chaves_dif) {

	unsigned chave_input;

	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);

	if(Remove(armazem,&chave_input)==1)
		*n_chaves_dif=*n_chaves_dif-1;
}
