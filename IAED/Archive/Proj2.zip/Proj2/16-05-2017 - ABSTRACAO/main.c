# include "ADT.h"

int main()
{
	int n_chaves_dif=0;

	link * armazem=Init();

	char op;

	do {
		op=getchar();
		switch(op)
		{
			case 'a':
				funcao_a(armazem, &n_chaves_dif);
				break;
			case 'l':
				PrintSorted(armazem);
				//funcao_l(armazem);
				break;
			case 'm':
				ShowMax(armazem, &n_chaves_dif);
				//funcao_m(armazem, &n_chaves_dif);
				break;
			case 'r':
				funcao_r(armazem, &n_chaves_dif);
				break;
		}

	} while(op!='x');


	//Ao sair, apresenta o numero de chaves diferentes;
	printf("%d\n", n_chaves_dif);
	FreeADT(armazem);

	return 0;
}
