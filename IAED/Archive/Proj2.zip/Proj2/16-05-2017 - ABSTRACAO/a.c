/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: a.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
# include "ADT.h"

void funcao_a(link armazem[DIM_TABLE], int * n_chaves_dif) {

	unsigned chave_input;
	int unidades_input;
	link *previous;
	link aux;

	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);
	//Para capturar o espaco que precede
	getchar();
	scanf("%d",&unidades_input);

	previous=Search(armazem, &chave_input);

	if ((*previous)==NULL || less_ab(chave_input,key((*previous)->produto))){

		aux=*previous;
		Insert(previous, NewItem(chave_input, unidades_input));
		(*previous)->next=aux;
		*(n_chaves_dif)=*(n_chaves_dif)+1;
	}
	else if (eq((*previous)->produto->chave,chave_input)){

		Update(previous,&unidades_input);
	}
}

