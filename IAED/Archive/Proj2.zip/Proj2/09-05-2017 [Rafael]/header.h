/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: header.h
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include <stdio.h>
# include <stdlib.h>

typedef struct produto *link;

struct produto{
	unsigned chave;
	int unidades;
	link next;
};



/*****************************************************************\
----------------------------PROTOTIPOS-----------------------------
\*****************************************************************/

link funcao_procura(link armazem[0x10], const unsigned chave);

unsigned hash(unsigned chave);

void funcao_a(link armazem[0xf], int * n_chaves_total, unsigned* max_unidades_chave, int * max_unidades);

void funcao_l(const link armazem[0x10]);

void funcao_m(const unsigned max_unidades_chave, const int max_unidades);

//void funcao_r(link armazem[0xf]);
