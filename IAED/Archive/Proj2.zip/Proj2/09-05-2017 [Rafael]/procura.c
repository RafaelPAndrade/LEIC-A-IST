/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: procura.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"

unsigned hash(unsigned chave) {
	return chave/0x10000000;
}



link funcao_procura(link armazem[0x10], const unsigned chave)
{
	//int primeiro_digito= hash(chave);
	//int primeiro_digito=chave/0x10000000;

	//link previous=armazem[primeiro_digito]; //, pt;
	link previous= armazem[hash(chave)];

	if(previous==NULL)
	{
		//return &armazem[primeiro_digito];<-retornaria ponteiro de ponteiro, nao o que eu quero...
		return previous;
	}

	//for(pt=previous;pt->chave<chave && pt->next!=NULL;previous=pt,pt=pt->next);

	//Trocar a ordem: ver se o proximo(next) e NULL antes de procurar a chave...
	for( ; previous->next != NULL && previous->chave < chave && previous->next->chave < chave; previous= previous->next);

	return previous;
}
