/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: client.h
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

# include "ADT.h"

void funcao_a(link armazem[DIM_TABLE]) {

	Key chave_input;
	int unidades_input;
	link *previous;
	link aux;

	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);
	//Para capturar o espaco que precede
	getchar();
	scanf("%d",&unidades_input);

	previous=Search(armazem, &chave_input);

	if ((*previous)==NULL || less(chave_input,key((*previous)->produto))){

		aux=*previous;
		Insert(previous, NewItem(chave_input, unidades_input));
		(*previous)->next=aux;
		n_chaves_dif+=1;
	}
	else if (eq((*previous)->produto->chave,chave_input)){

		Update(previous,&unidades_input);
	}

	if((*previous)->produto->unidades>max_unidades)
	{
		max_unidades=(*previous)->produto->unidades;
		max_unidades_chave=(*previous)->produto->chave;
		max_n_chaves_ins=1;
		flag=2;
	}else if((*previous)->produto->unidades==max_unidades && (*previous)->produto->chave<max_unidades_chave)
	{
		max_unidades_chave=(*previous)->produto->chave;
		max_n_chaves_ins+=1;
		flag=2;
	}
	else if((*previous)->produto->chave==max_unidades_chave && unidades_input<0)
	{
		max_n_chaves_ins-=1;
		flag=1;
	}else if(unidades_input!=0 && max_n_chaves_ins>1)
	{
		max_n_chaves_ins-=1;
		if(max_n_chaves_ins==0)
			flag=1;
	}
}

void funcao_r(link armazem[DIM_TABLE]) {

	Key chave_input;

	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);

	if(Remove(armazem,&chave_input)==1)
		n_chaves_dif-=1;
}