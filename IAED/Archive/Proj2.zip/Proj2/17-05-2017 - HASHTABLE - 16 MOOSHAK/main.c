/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: main.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

# include "client.h"

int main()
{
	link * armazem=Init();

	max_unidades=-1;
	max_unidades_chave=0xFFFFFFFF;

	char op;

	do {
		op=getchar();
		switch(op)
		{
			case 'a':
				funcao_a(armazem);
				break;
			case 'l':
				PrintSorted(armazem);
				break;
			case 'm':
				ShowMax(armazem);
				break;
			case 'r':
				funcao_r(armazem);
				break;
		}

	} while(op!='x');


	//Ao sair, apresenta o numero de chaves diferentes;
	printf("%d\n", n_chaves_dif);
	FreeADT(armazem);

	return 0;
}
