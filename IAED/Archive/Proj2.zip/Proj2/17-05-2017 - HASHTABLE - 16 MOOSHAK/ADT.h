/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: ADT.h
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

/*
Estrutura escolhida: encadeamento externo
link armazem[DIM_TABLE];
*/

# ifndef _ADT_
# define _ADT_

# include "Item.h"

//# define N_CHAVES  0x100000000
# define DIM_TABLE 0x1000
//Numero de digitos da chave que queremos considerar
# define DIVISOR_HASH 0x100000

typedef struct node{
	Item produto;
	struct node * next;
} * link;

int n_chaves_dif;

int max_unidades;
Key max_unidades_chave;
int max_n_chaves_ins;

//Flag que controla se max_unidades existe mais do que uma vez
int flag;

/**************************************\
|Prototipos
\**************************************/

int hash(const Key * chave);
link * Search(link armazem[DIM_TABLE], const Key * chave);
link * Init(void);

void Insert(link * previous, Item a);
void Update(link * node, int * variacao_produto);

int Remove(link armazem[DIM_TABLE], Key * chave);
void PrintSorted(link armazem[DIM_TABLE]);
void FreeADT(link armazem[DIM_TABLE]);
void ShowMax(link armazem[DIM_TABLE]);

# endif
