/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: r.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"

void funcao_r(link armazem[DIM_HASH_TABLE], int * n_chaves_total, unsigned * max_unidades_chave, int * max_unidades)
{
	unsigned chave_input;
	link *previous, aux;

	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);

	previous=funcao_procura(armazem,&chave_input);

	if((*previous)!=NULL && (*previous)->produto->chave==chave_input)
	{
		aux=*previous;
		*previous=(*previous)->next;
		free_produto(aux);

		*(n_chaves_total)=*(n_chaves_total)-1;
	}

	if(*max_unidades_chave==chave_input)
	{
		flag=1;//actualiza_m(armazem, max_unidades_chave, max_unidades);
	}

}
