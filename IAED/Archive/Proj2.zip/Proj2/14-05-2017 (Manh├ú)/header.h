/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: header.h
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

#include <stdio.h>
#include <stdlib.h>
#define DIM_HASH_TABLE 65536
#define HASH 0x10000 //0x100000 4096 //0x1000000 256 //0x10000000; DIM_HASH_TABLE 16
#define CHAVE_MAX 0xFFFFFFFF
#define INI_VALORES 0

int flag;

typedef struct node *link;

typedef struct produto{
	unsigned chave;
	int unidades;
} *Produto;

struct node{
	Produto produto;
	link next;
};

/*****************************************************************\
----------------------------PROTOTIPOS-----------------------------
\*****************************************************************/
void free_produto(link no);

void actualiza_m(const link armazem[DIM_HASH_TABLE], unsigned * max_unidades_chave, int * max_unidades);



link * funcao_procura(link armazem[DIM_HASH_TABLE], const unsigned * chave);

unsigned hash(const unsigned * chave);

void funcao_a(link armazem[DIM_HASH_TABLE], int * n_chaves_total, unsigned* max_unidades_chave, int * max_unidades);

void funcao_l(const link armazem[DIM_HASH_TABLE]);

void funcao_m(const link armazem[DIM_HASH_TABLE], unsigned * max_unidades_chave, int * max_unidades, const int * n_chaves_diff );//, const unsigned * max_unidades_chave, const int * max_unidades, const int * n_chaves_diff );

void funcao_r(link armazem[DIM_HASH_TABLE], int * n_chaves_total, unsigned * max_unidades_chave, int * max_unidades);

void free_Armazem(link armazem[DIM_HASH_TABLE], int n_sublistas);

