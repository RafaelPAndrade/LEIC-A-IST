/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: a.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"

void funcao_a(link armazem[DIM_HASH_TABLE], int * n_chaves_total ,unsigned * max_unidades_chave, int * max_unidades) {

	unsigned chave_input;
	int unidades_input;
	link *previous;
	link aux;


	//Para capturar o espaco que precede
	getchar();
	scanf("%x",&chave_input);
	//Para capturar o espaco que precede
	getchar();
	scanf("%d",&unidades_input);

	previous=funcao_procura(armazem, &chave_input);

	if ((*previous)==NULL || (*previous)->produto->chave > chave_input){
		//Acontece sem elementos na lista
		aux=*previous;
		(*previous) = (link) malloc(sizeof(struct node));
		(*previous)->produto = (Produto) malloc(sizeof(struct produto));
		(*previous)->produto->chave= chave_input;
		(*previous)->produto->unidades= (unidades_input > 0) ? unidades_input : INI_VALORES;
		(*previous)->next= aux;
		*(n_chaves_total)=*(n_chaves_total)+1;
	}

	else if ((*previous)->produto->chave == chave_input){
		//Acontece com um produto ja com a mesma chave_input
		(*previous)->produto->unidades= ((*previous)->produto->unidades + unidades_input > 0) ? (*previous)->produto->unidades+unidades_input : INI_VALORES;
	}


	if ( flag==0 && ((*previous)->produto->unidades > *(max_unidades) || ( (*previous)->produto->unidades == *(max_unidades) && (*previous)->produto->chave < *(max_unidades_chave) )) ){
		*(max_unidades)= (*previous)->produto->unidades;
		*(max_unidades_chave)= (*previous)->produto->chave;
	}
	else
	{
		flag=1;
		//actualiza_m(armazem, max_unidades_chave, max_unidades);
	}
}
