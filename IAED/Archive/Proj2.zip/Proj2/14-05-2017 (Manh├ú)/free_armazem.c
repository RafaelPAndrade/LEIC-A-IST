#include "header.h"

void free_Armazem(link armazem[DIM_HASH_TABLE], int n_sublistas){

	link aux, next;

	for (; --n_sublistas>=0; ){
		aux=armazem[n_sublistas];
		while (aux != NULL){
			next=aux->next;
			free_produto(aux);
			aux=next;
		}
	}
}
