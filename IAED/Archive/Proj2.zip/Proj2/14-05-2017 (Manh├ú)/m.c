/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: m.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"


void funcao_m(const link armazem[DIM_HASH_TABLE], unsigned * max_unidades_chave, int * max_unidades, const int * n_chaves_diff ){

	if(*n_chaves_diff!=0)
	{
		if(flag==1)
		{
			actualiza_m(armazem, max_unidades_chave, max_unidades);
			flag=0;
		}
		printf("%.8x %d\n", *max_unidades_chave, *max_unidades);
	}
}
