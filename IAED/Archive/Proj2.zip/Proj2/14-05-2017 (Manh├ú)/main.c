/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: main.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"

int main()
{
	int n_chaves_dif=INI_VALORES;

	link armazem[DIM_HASH_TABLE] = { NULL };

	unsigned max_unidades_chave=CHAVE_MAX;
	int max_unidades=INI_VALORES;

	//Caractere que representa o comando a executar
	char op;

	do {
		op=getchar();
		switch(op)
		{
			case 'a':
				funcao_a(armazem, &n_chaves_dif ,&max_unidades_chave, &max_unidades);
				break;
			case 'l':
				funcao_l(armazem);
				break;
			case 'm':
				funcao_m(armazem,&max_unidades_chave, &max_unidades, &n_chaves_dif);
				break;
			case 'r':
				funcao_r(armazem, &n_chaves_dif, &max_unidades_chave, &max_unidades);
				break;
		}

	} while(op!='x');


	//Ao sair, apresenta o numero de chaves diferentes;
	printf("%d\n", n_chaves_dif);
	free_Armazem(armazem, DIM_HASH_TABLE);
	return 0;
}
