#include "header.h"

void free_produto(link no)
{
	free(no->produto);
	free(no);
}


void actualiza_m(const link armazem[DIM_HASH_TABLE], unsigned * max_unidades_chave, int * max_unidades)
{
	int i;
	link pt;
	*max_unidades_chave=CHAVE_MAX;
	*max_unidades=INI_VALORES;
	for(i=INI_VALORES;i<DIM_HASH_TABLE;i++)
		for(pt=armazem[i];pt!=NULL;pt=pt->next)
			if(pt->produto->unidades>*max_unidades || ((pt->produto->unidades==*max_unidades) && pt->produto->chave<*max_unidades_chave))
			{
				*max_unidades_chave=pt->produto->chave;
				*max_unidades=pt->produto->unidades;
			}
}