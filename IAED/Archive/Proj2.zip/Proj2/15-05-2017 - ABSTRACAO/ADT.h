/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: ADT.h
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

/*
Estrutura escolhida: encadeamento externo
link armazem[DIM_TABLE];
*/

# include "Item.h"

# define N_CHAVES  0x100000000
# define DIM_TABLE 0x10000
//Numero de digitos da chave que queremos considerar
# define DIVISOR_HASH 0x10000

typedef struct node{
	Item produto;
	struct node * next;
} * link;


/**************************************\
|Prototipos
\**************************************/

int hash(unsigned chave);
link * Search(link armazem[DIM_TABLE], unsigned chave);
link * Init(int n_listas);

void Insert(link * previous, Item a);
void Update(link * node, int variacao_produto);

int Remove(link armazem[DIM_TABLE], unsigned chave);
void PrintSorted(link armazem[DIM_TABLE]);
void FreeADT(link armazem[DIM_TABLE]);
void ShowMax(link armazem[DIM_TABLE]);
