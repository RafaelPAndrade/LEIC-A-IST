/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: Item.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

# include "Item.h"

Item NewItem(unsigned new_chave, int new_unidades){

	Item res= (Item) malloc( sizeof(struct produto) );
	res->chave= new_chave;
	res->unidades= new_unidades;

	return res;
}

void ShowItem(Item a){

	printf("%.8x %d\n", a->chave, a->unidades);
}

int less(Item a, Item b){

	if (a->unidades < b->unidades)
		return 1;
	else if (a->unidades == b->unidades && a->chave < b->chave)
		return 1;
	else
		return 0;
}

void freeItem(Item a){

	free(a);
}
