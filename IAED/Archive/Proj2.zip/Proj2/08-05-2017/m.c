/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: m.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"


void funcao_m(const unsigned max_unidades_chave, const int max_unidades){


	printf("%.8x %d", max_unidades_chave, max_unidades);

}
