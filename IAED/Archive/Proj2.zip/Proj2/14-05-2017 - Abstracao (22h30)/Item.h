/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: Item.h
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
# include <stdlib.h>
# include <stdio.h>

typedef struct produto{
	unsigned chave;
	int unidades;
} * Item;

typedef struct node{
	Item produto;
	struct node * next;
} * link;



/*********************************\
|Prototipos
\*********************************/

Item NewItem(unsigned chave, int unidades);
void ShowItem(Item a);
int less(Item a, Item b);
void freeItem(Item a);
