/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: ADT.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/

# include "ADT.h"

int hash(unsigned chave){

	return (int) chave / DIVISOR_HASH;
}

link * Search(link armazem[DIM_TABLE], unsigned chave)
{
	link * aux = armazem + hash(chave);

	//Trocar a ordem: ver se o proximo(next) e NULL antes de procurar a chave...
	for( ; (*aux) != NULL && (*aux)->produto->chave < chave; aux=&( (*aux)->next));

	return aux;
}

/*link Init(int n_listas)
{

}*/

void Insert(link * previous, Item a)
{
	link aux=*previous;
	*previous=(link)malloc(sizeof(struct node));
	(*previous)->produto=NewItem(a->chave,a->unidades);
	(*previous)->next=aux;
}

void Update(link * node, int variacao_produto)
{
	(*node)->produto->unidades=((*node)->produto->unidades + variacao_produto > 0) ? (*node)->produto->unidades+variacao_produto : 0;
}

/*void Remove(link armazem[DIM_TABLE], unsigned chave)
{

}*/

void PrintSorted(link armazem[DIM_TABLE])
{
	int i;
	link ptr;
	for(i=0;i<DIM_TABLE;i++)
		for(ptr=armazem[i];ptr!=NULL;ptr=ptr->next)
			ShowItem(ptr->produto);
}


void FreeADT(link armazem[DIM_TABLE])
{
	int i;
	link aux, next;
	for (i=0;i<DIM_TABLE;i++){
		aux=armazem[i];
		while (aux != NULL){
			next=aux->next;
			freeItem(aux->produto);
			free(aux);
			aux=next;
		}
	}
}

/*void ShowMax(link armazem[DIM_TABLE])
{

}*/



