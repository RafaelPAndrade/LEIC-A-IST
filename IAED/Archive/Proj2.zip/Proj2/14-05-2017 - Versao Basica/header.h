/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: header.h
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include <stdio.h>
# include <stdlib.h>
#define DIM_HASH_TABLE 65536
#define HASH 0x10000 //0x10000 65536 //0x100000 4096 //0x1000000 256 //0x10000000; DIM_HASH_TABLE 16
#define CHAVE_MAX 0xFFFFFFFF

typedef struct produto *link;

struct produto{
	unsigned chave;
	int unidades;
	link next;
};



/*****************************************************************\
----------------------------PROTOTIPOS-----------------------------
\*****************************************************************/
link * funcao_procura(link armazem[DIM_HASH_TABLE], const unsigned * chave);

unsigned hash(const unsigned * chave);

void funcao_a(link armazem[DIM_HASH_TABLE], int * n_chaves_total);

void funcao_l(const link armazem[DIM_HASH_TABLE]);

void funcao_m(const link armazem[DIM_HASH_TABLE], const int * n_chaves_diff );

void funcao_r(link armazem[DIM_HASH_TABLE], int * n_chaves_total);

void free_Armazem(link armazem[DIM_HASH_TABLE], int n_sublistas);
