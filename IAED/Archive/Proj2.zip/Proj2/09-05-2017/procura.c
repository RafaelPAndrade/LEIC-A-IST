/*****************************************************************\
|IAED 2016/17 Projeto 2 - entradas/saidas de produtos num armazem
|Ficheiro: a.c
|
|Livio Mendes Costa
|Rafael Pestana de Andrade
\*****************************************************************/
#include "header.h"

/*funcao_a()
{
	scanf("%x",&);

	scanf("%d",&);
}*/

link funcao_procura(link armazem[0x10], const unsigned chave)
{
	int primeiro_digito=chave/0x10000000;

	link previous=armazem[primeiro_digito]; //, pt;

	if(previous==NULL)
	{
		return previous;
	}

	//for(pt=previous;pt->chave<chave && pt->next!=NULL;previous=pt,pt=pt->next);

	for(;previous->next->chave<chave && previous->next!=NULL;previous=previous->next);

	return previous;
}