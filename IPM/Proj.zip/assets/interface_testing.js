window.addEventListener('DOMContentLoaded', function() {$("#results_content").val("");$("#iRave").toggle();$("#results").toggle();$("#finished").toggle();}, true);


/* Test1 */
var telemetry_test1;
function start_test1(){
  telemetry_test1 = new Telemetry("test1");
  set_current_telemetry(telemetry_test1);

  console.log("starting test 1");
  $("#iRave").toggle();
  init_simulation();
  t1_starttime = performance.now();
  console.log("NAME")
  console.log(arguments.callee.name)
}

function stop_test1(){
  console.log("stopping test 1");
  telemetry_test1.stop(); // stops the timer
  $("#results_content").val(telemetry_test1.print_metrics()+"\n")

  $("#iRave").toggle();
  console.log(telemetry_test1.metrics)
}



/* Test2 */
var telemetry_test2;
function start_test2(){
  telemetry_test2 = new Telemetry("test2");
  set_current_telemetry(telemetry_test2);

  console.log("starting test 2");
  $("#iRave").toggle();
  init_simulation();
  t2_starttime = performance.now();

}

function stop_test2(){

  console.log("stopping test 2");
  telemetry_test2.stop(); // stops the timer

  $("#results_content").val($("#results_content").val()+telemetry_test2.print_metrics()+"\n")
  $("#iRave").toggle();
}



/* Test3 */
var telemetry_test3;
function start_test3(){
  telemetry_test3 = new Telemetry("test3");
  set_current_telemetry(telemetry_test3);

  console.log("starting test 3");
  $("#iRave").toggle();
  init_simulation();
}

function stop_test3(){
  $("#finished").toggle();
  console.log("stopping test 3");
  telemetry_test3.stop(); // stops the timer

  $("#results_content").val($("#results_content").val()+telemetry_test3.print_metrics())
  $("#iRave").toggle();
  $("#results").toggle();
}
