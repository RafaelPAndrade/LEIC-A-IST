/*
 * Telemetry related functions
 */

/* READTHEDOCS:
      to count the number of times a function was called add to the function the following line
        telemetry_func_called(arguments.callee.name);

    > How to create telemetry for a new test?
        telemetry_test = new Telemetry();
        set_current_telemetry(telemetry_test);

      now telemetry test is the object storing the telemetry results.

    > How to get the telemetry's results?
        telemetry_test.metrics()
      return a dict with all the metrics

 */

/* stores the number of calls of each function */
class Telemetry {
  constructor(test_name) {
    this.start_time = performance.now();
    this.metrics = {
      name: test_name,
      duration: 0,
      function_calls:{},
    };
  }
  func_called(func_name){
    if (!(func_name in this.metrics.function_calls)) this.metrics.function_calls[func_name]=1;
    else this.metrics.function_calls[func_name]+=1;
  }

  stop(){ // stops the time counter
    this.metrics.duration = Math.round(performance.now() - this.start_time)
  }

  print_metrics(){
    return this.metrics.name+", "+this.metrics.duration
  }

}

var current_telemetry;
function set_current_telemetry(new_telemetry) {
  current_telemetry = new_telemetry;
}
function get_current_telemetry() {
  return current_telemetry;
}



var metrics_num_calls = {}

//arguments.callee.name
function telemetry_func_called(func_name) {
  telemetry = get_current_telemetry();
  if (!telemetry) return; // does nothing if we are not in any test
  telemetry.func_called(func_name);
}
