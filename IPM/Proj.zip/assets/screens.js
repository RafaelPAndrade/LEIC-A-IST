var config_dict = {
    "initial_screen":{screen:
                          { type:'main_screen',
                            band:'by Queen',
                            song:'♫ Bohemian Rhapsody',
                            click:'function(){set_screen("main_menu")}',
                            callback:'update_time',
                            cleanup:'function(){clear_screen_timers()}',
                            onrestore:'function(){console.log("Restoring main screen..."); update_time();}'
                          },
                        bar:
                          { type:'triple',
                            array:[{logo:"./assets/icons/emergency_call_small.svg", style:"bar-color_blue", click:'function(){set_screen("emergency_call")}'},
                                   {logo:"./assets/icons/exit_small.svg", style:"bar-color_blue", click:'function(){click_on_leave_screen()}'},
                                   {logo:"./assets/icons/menu.svg", style:"bar-color_blue", click:'function(){set_screen("main_menu")}'} ]
                          }
                       },
    "main_menu":{screen:
                    { type:'slider_menu',
                      views:[ {title:'', logo:'./assets/icons/fast_food.svg', label:'Comida', id:'food_choose_restaurant'},
                              {title:'', logo:'./assets/icons/group-button.svg', label:'Amigos', id:'friends_screen'},
                              {title:'', logo:'./assets/icons/exit.svg', label:'Sair do Recinto', id:'leave_screen'},
                              {title:'', logo:'./assets/icons/emergency_call.svg', label:'Emergência', id:'emergency_call'},],
                      click: 'click_on_main_menu'
                    },
                  bar:
                    { type:'double',
                      array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'restore_last_screen'},
                              {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'click_on_main_menu'} ]
                    }
                  },
    "emergency_call":{screen:
                    { type:'slider_menu',
                      views:[ {title:'Chamar quem?', logo:'./assets/icons/red_cross.svg', label:'Médicos', id:'medic'},
                              {title:'Chamar quem?', logo:'./assets/icons/security_man.svg', label:'Seguranças', id:'security'},
                              {title:'Chamar quem?', logo:'./assets/icons/PSP.svg', label:'PSP', id:'PSP'} ],
                      click: 'function(){var c=get_slider_selected_id();set_screen("confirm_"+c+"_call")}'
                    },
                  bar:
                    { type:'double',
                      array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'restore_last_screen'},
                              {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){var c=get_slider_selected_id();set_screen("confirm_"+c+"_call")}'} ]
                    }
                  },
    "confirm_medic_call":{screen:
                        { type:'dynamic_info',
                          title:'Tem a certeza?',
                          image:'./assets/icons/red_cross.svg',
                          content:'Ação não pode ser cancelada',
                          next_up: ['Chamar Médicos?'],
                          callback: 'rotate_content'
                        },
                      bar:
                        { type:'double',
                          array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'restore_last_screen'},
                                  {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){set_screen("medic_call")}'} ]
                        }
                      },
     "medic_call":{screen:
                        { type:'dynamic_info',
                          title:'A chamar...',
                          image:'./assets/icons/red_cross.svg',
                          content:'Médicos',
                          next_up: ['Tempo: 3min', 'Médicos', 'Tempo: 1min', 'Não saia do sítio', 'Tempo: 30s'],
                          click:'unlock_screen',
                          callback:'function() { lock_screen(); rotate_content();}'
                        },
                      bar:
                        { type:'double',
                          array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'lock_screen'},
                                  {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'go_to_first_screen_and_discard' } ]
                        }
                      },
   "confirm_security_call":{screen:
                        { type:'dynamic_info',
                          title:'Tem a certeza?',
                          image:'./assets/icons/security_man.svg',
                          content:'Ação não pode ser cancelada',
                          next_up: ['Chamar Seguranças?'],
                          callback: 'rotate_content'
                        },
                      bar:
                        { type:'double',
                          array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'restore_last_screen'},
                                  {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){set_screen("security_call")}'} ]
                        }
                      },
    "security_call":{screen:
                        { type:'dynamic_info',
                          title:'A chamar...',
                          image:'./assets/icons/security_man.svg',
                          content:'Seguranças',
                          next_up: ['Tempo: 3min', 'Seguranças', 'Tempo: 1min', 'Não saia do sítio', 'Tempo: 30s'],
                          click:'unlock_screen',
                          callback:'function(){lock_screen(); rotate_content();}'
                        },
                      bar:
                        { type:'double',
                          array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'lock_screen'},
                                  {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'go_to_first_screen_and_discard' } ]
                        }
                      },
    "confirm_PSP_call":{screen:
                        { type:'dynamic_info',
                          title:'Tem a certeza?',
                          image:'./assets/icons/PSP.svg',
                          content:'Ação não pode ser cancelada',
                          next_up: ['Chamar PSP?'],
                          callback: 'rotate_content'
                        },
                      bar:
                        { type:'double',
                          array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'restore_last_screen'},
                                  {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){set_screen("PSP_call")}' } ]
                        }
                      },
    "PSP_call":{screen:
                        { type:'dynamic_info',
                          title:'A chamar...',
                          image:'./assets/icons/PSP.svg',
                          content:'PSP',
                          next_up: ['Tempo: 3min', 'PSP', 'Tempo: 1min', 'Não saia do sítio', 'Tempo: 30s'],
                          click:'unlock_screen',
                          callback:'function(){ lock_screen(); rotate_content();}'

                        },
                      bar:
                        { type:'double',
                          array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'lock_screen'},
                                  {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'go_to_first_screen_and_discard' } ]
                        }
                      },
    // leave screen but
    "pending_ride":{screen:
              { type:'info',
                title:'Já tem boleia ',
                image:'./assets/icons/piggyback_cancel.svg',
                content:'Cancelar',

                // change the icon the the apropriate ride
                callback:'function(){\
                  $("#image").attr("src","./assets/icons/"+Cookies.get("ride")+"_cancel.svg")  \
                }'
              },
            bar:
              { type:'double',
                array:[ {logo:"./assets/icons/ok.svg", style:"bar-color_yellow", click:'function(){cancel_ride();console.log("ride was canceled");restore_last_screen()}'},
                        {logo:"./assets/icons/cancel.svg", style:"bar-color_green", click:'restore_last_screen' } ]
              }
            },

    "leave_screen":{screen:
                    { type:'slider_menu',
                      views:[ {title:'', logo:'./assets/icons/taxi.svg', label:'Taxi', id:'taxi'},
                              {title:'', logo:'./assets/icons/piggyback.svg', label:'Dar Boleia', id:'piggyback'},
                            /*{title:'', logo:'./assets/icons/uber.svg', label:'Uber', id:'uber'}*/ ],
                      click: 'function(){var c=get_slider_selected_id();Cookies.set("ride",c);set_screen(c+"_ride")}',
                      callback:'function(){if (get_friends().length===0) {console.log("NOO FRIENDS");restore_last_screen();set_screen("leave_screen_no_friends")}}',
                    },
                  bar:
                    { type:'double',
                      array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'restore_last_screen'},
                              {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){var c=get_slider_selected_id();Cookies.set("ride",c);set_screen(c+"_ride")}'} ]
                    }
                  },
    "leave_screen_no_friends":{screen:
                    { type:'slider_menu',
                      views:[ {title:'', logo:'./assets/icons/taxi.svg', label:'Taxi', id:'taxi_ride'},
                              {title:'', logo:'./assets/icons/piggyback_disabled.svg', label:'Dar Boleia', id:'no_friends'},
                            /*{title:'', logo:'./assets/icons/uber.svg', label:'Uber', id:'uber'}*/ ],
                      click: 'function(){var c=get_slider_selected_id();Cookies.set("ride",c);set_screen(c);}',
                      callback:'function(){if (get_friends().length!==0) {restore_last_screen();set_screen("leave_screen")}}',
                      onrestore:'function(){if (get_friends().length!==0) {this.use_this=false;set_screen("leave_screen")}}',
                    },
                  bar:
                    { type:'double',
                      array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'restore_last_screen'},
                              {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){var c=get_slider_selected_id();Cookies.set("ride",c);set_screen(c);}'} ]
                    }
                  },
    // informs the user that such action is not permitted since she/he has no friends
    "no_friends":{screen:
              { type:'info',
                title:'Adicione',
                image:'./assets/icons/piggyback_disabled.svg',
                content:'primeiro </br> Amigos',
                click:'function(){wants_friends_screen()}',
                onrestore:'function(){if (get_friends().length!==0) {console.log("now has friends"); this.use_this=false;restore_last_screen();}}',
              },
            bar:
              { type:'double',
                array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'restore_last_screen'},
                        {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){wants_friends_screen()}' } ]
              }
            },

    "piggyback_ride":{screen:
              { type:'info',
                title:'Seleccione ',
                image:'./assets/icons/piggyback.svg',
                content:'Amigos',
                click:'function(){set_screen(json_gen_select_friends())}',
              },
            bar:
              { type:'double',
                array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'restore_last_screen'},
                        {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){set_screen(json_gen_select_friends())}' } ]
              }
            },

    "piggyback_ride_time_select":{screen:
                    { type:'info_menu_ammount',
                      title:'Boleia em',
                      image:'',
                      content:'5</br> minutos',
                      callback: 'function(){init_ammount_selector(5,120,decrease_info_quantity,increase_info_quantity,exit_festival_listen);}' /* sets up the event listeners */

                    },
                  bar:
                    { type:'double',
                      array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'restore_last_screen'},
                              {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'check_if_can_exit_festival'} ]
                    }
                  },


    "piggyback_ride_confirm":{screen:
              { type:'info',
                title:'Seleccione ',
                image:'./assets/icons/piggyback.svg',
                content:'Amigos',
                click:'function(){set_screen(json_gen_select_friends())}',
              },
            bar:
              { type:'double',
                array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'restore_last_screen'},
                        {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){set_screen(json_gen_select_friends())}' } ]
              }
            },

    "piggyback_accept_ride":{screen:
              { type:'info',
                title:'Carlos Oliveira',
                image:'./assets/icons/piggyback.svg',
                content:'oferece boleia </br> em <b>20 mins</b>',
                },
            bar:
              { type:'double',
                array:[ {logo:"./assets/icons/cancel.svg", style:"bar-color_red", click:'function(){set_screen("piggyback_refuse_ride_confirm")}'},
                        {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){click_on_piggyback_accept_ride();}' } ]
              }
            },
    "piggyback_accept_ride_confirm":{screen:
              { type:'info',
                title:'Aceitou',
                image:'./assets/icons/piggyback.svg',
                content:'boleia em<br><b>20 mins</b>',
                },
            bar:
              { type:'uni',
                  array:[ {logo:"./assets/icons/ok.svg", style:"bar-color_blue_circle_uni", click:'function(){Cookies.set("when-arrived-at-dest","find_friend");Cookies.set("ride","piggyback_me");set_ride(Cookies.get("ride"),build_notification(20*1000*60, Cookies.get("ride")+" ride",  Cookies.get("ride")+"_ride_almost_arrived","no info","ride"));restore_last_nth_screen(2);}',} ]
              }
            },
    "piggyback_refuse_ride_confirm":{screen:
              { type:'info',
                title:'Recusar?',
                image:'./assets/icons/piggyback.svg',
                content:'Boleia',
                },
            bar:
              { type:'double',
                array:[{logo:"./assets/icons/cancel.svg", style:"bar-color_green", click:'restore_last_screen' },
                       {logo:"./assets/icons/ok.svg", style:"bar-color_red", click:'function(){restore_last_nth_screen(2)}'}]
              }
            },

    "taxi_ride":{screen:
                    { type:'info_menu_ammount',
                      title:'Chegar em',
                      image:'',
                      content:'5</br> minutos',
                      callback: 'function(){init_ammount_selector(5,60,decrease_info_quantity,increase_info_quantity,exit_festival_listen);}' /* sets up the event listeners */

                    },
                  bar:
                    { type:'double',
                      array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'restore_last_screen'},
                              {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'check_if_can_exit_festival'} ]
                    }
                  },
      "ride_confirm":{screen:
                          { type:'info',
                            title:'Confirmar boleia',
                            image:'./assets/icons/taxi.svg',
                            content:'testing',
                            click:'function(){Cookies.set("when-arrived-at-dest","return_iRave");set_ride(Cookies.get("ride"),build_notification(get_current_ammount()*1000*60, Cookies.get("ride")+" ride",  Cookies.get("ride")+"_almost_arrived"),"no info","ride");go_to_first_screen_and_discard()}',
                            callback:'function(){\
                              $("#info-content").html(get_current_ammount()+" minutos"); \
                              $("#image").attr("src","./assets/icons/"+Cookies.get("ride")+".svg")  \
                            }'
                          },
                        bar:
                          { type:'double',
                            array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'restore_last_screen'},
                                    {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){Cookies.set("when-arrived-at-dest","return_iRave");set_ride(Cookies.get("ride"),build_notification(get_current_ammount()*1000*60, Cookies.get("ride")+" ride",  Cookies.get("ride")+"_almost_arrived","no info","ride"));go_to_first_screen_and_discard()}' } ]
                          }
                        },

    "taxi_ride_almost_arrived":{screen:
                        { type:'dynamic_info',
                          title:'Boleia',
                          image:'./assets/icons/destination_path.svg',
                          content:'Boleia chega</br> em momentos',
                          next_up: ['Siga a</br> Bússula','Para chegar </br>à saída'],
                          callback: 'function(){rotate_content();}', //delete_ride();
                          click:'function(){set_screen("navigator_ride")}',
                        },
                      bar:
                        { type:'double',
                          array:[ {logo:"./assets/icons/cancel.svg", style:"bar-color_red", click:'function(){set_screen("want_to_go_on_your_own_ride")}'},
                                  {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){set_screen("navigator_ride")}'} ]
                        }
                      },
    "piggyback_almost_arrived":{screen:
                        { type:'dynamic_info',
                          title:'Boleia',
                          image:'./assets/icons/destination_path.svg',
                          content:'Dá Boleia</br> em momentos',
                          next_up: ['Siga a</br> Bússula','Para chegar </br>à saída'],
                          callback: 'function(){rotate_content();delete_ride();}',
                          click:'function(){set_screen("navigator_ride")}',
                        },
                      bar:
                        { type:'double',
                          array:[ {logo:"./assets/icons/cancel.svg", style:"bar-color_red", click:'function(){set_screen("want_to_go_on_your_own_ride_friend")}'},
                                  {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){set_screen("navigator_ride")}'} ]
                        }
                      },
    // when someone is being piggybacked
    "piggyback_me_ride_almost_arrived":{screen:
                        { type:'dynamic_info',
                          title:'Boleia',
                          image:'./assets/icons/destination_path.svg',
                          content:'recebe Boleia</br> em momentos',
                          next_up: ['Siga a</br> Bússula','Para encontar </br>amigo'],
                          callback: 'function(){rotate_content();delete_ride();}',
                          click:'function(){set_screen("navigator_ride")}',
                        },
                      bar:
                        { type:'double',
                          array:[ {logo:"./assets/icons/cancel.svg", style:"bar-color_red", click:'function(){set_screen("want_to_go_on_your_own_ride")}'},
                                  {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){set_screen("navigator_ride")}'} ]
                        }
                      },
    // a user can choose not to go with the friend
    "piggyback_me_ride_almost_arrived_deny":{screen:
                        { type:'info',
                          title:'Recusar?',
                          image:'./assets/icons/piggyback_cancel.svg',
                          content:'',
                        },
                      bar:
                        { type:'double',
                          array:[ {logo:"./assets/icons/ok.svg", style:"bar-color_red", click:'function(){delete_ride();set_screen("friend_will_be_notified")}'},
                                  {logo:"./assets/icons/undo.svg", style:"bar-color_green", click:'restore_last_screen' } ]
                        }
                      },

    // the friend will be notified that you are not going
    "friend_will_be_notified":{screen:
                        { type:'info',
                          title:'Amigo',
                          image:'./assets/icons/piggyback_cancel.svg',
                          content:'notificado',
                        },
                      bar:
                        { type:'uni',
                          array:[ {logo:"./assets/icons/ok.svg", style:"bar-color_blue_circle_uni", click:'function(){go_to_first_screen_and_discard()}'},]
                        }
                      },



    // when the user arrives at the supposed piggyback location she/he will have to look for the piggybacking friend
    "find_friend":{screen:
                        { type:'info',
                          title:'Procure o',
                          image:'./assets/icons/piggyback.svg',
                          content:'seu amigo',
                        },
                      bar:
                        { type:'double',
                          array:[ {logo:"./assets/icons/cancel.svg", style:"bar-color_red", click:'function(){set_screen("find_friend_give_up")}'},
                                  {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){set_screen("return_iRave")}' } ]
                        }
                      },

    "find_friend_give_up":{screen:
              { type:'info',
                title:'Desistir?',
                image:'./assets/icons/piggyback_cancel.svg',
                content:'Boleia',
                },
            bar:
              { type:'double',
                array:[ {logo:"./assets/icons/ok.svg", style:"bar-color_red", click:'function(){delete_ride();set_screen("friend_will_be_notified")}'},
                        {logo:"./assets/icons/cancel.svg", style:"bar-color_green", click:'restore_last_screen' } ]
              }
            },

    "find_friend_found":{screen:
              { type:'info',
                title:'Encontrou?',
                image:'./assets/icons/piggyback.svg',
                content:'',
                },
            bar:
              { type:'double',
                array:[ {logo:"./assets/icons/cancel.svg", style:"bar-color_red", click:'function(){restore_last_screen()}'},
                        {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'set_screen("return_iRave")' } ]
              }
            },

    "navigator_ride":{screen:
                        { type:'navigator',
                          title:'Navigator',
                          image:'./assets/icons/navigation.svg',
                          content:'35 passos',
                          callback:'function(){navigate(),update_navigator(0);}',
                          cleanup:'function(){clear_path_timeouts();console.log("clearing path thimeouts");}',
                       },
                      bar:
                        { type:'uni',
                          array:[ {logo:"./assets/icons/cancel.svg", style:"bar-color_blue_circle_uni", click:'function(){set_screen("want_to_go_on_your_own_ride")}'}]
                        }
                      },

    // in case the person wants to go by their own
    "want_to_go_on_your_own_ride":{screen:
                        { type:'info',
                          title:'Consigo',
                          image:'./assets/icons/destination_path.svg',
                          content:'ir sozinha(o)',
                          click:'function(){set_screen("return_iRave")}',
                        },
                      bar:
                        { type:'double',
                          array:[{logo:"./assets/icons/cancel.svg", style:"bar-color_red", click:'function(){set_screen("navigator_ride")}'},
                                 {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'go_to_first_screen_and_discard'}]
                        }
                      },

    // in case the person wants to go by their own
    "want_to_go_on_your_own_ride_friend":{screen:
                        { type:'info',
                          title:'Encontrar amiga(o)',
                          image:'./assets/icons/destination_path.svg',
                          content:'<b>sozinha(o)</b>',
                        },
                      bar:
                        { type:'double',
                          array:[ {logo:"./assets/icons/ok.svg", style:"bar-color_red", click:'go_to_first_screen_and_discard'},
                                  {logo:"./assets/icons/cancel.svg", style:"bar-color_green", click:'function(){set_screen("navigator_ride")}'} ]
                        }
                      },

    "ride_arrived":{screen:
                        { type:'info',
                          title:'',
                          image:'./assets/icons/destination_path.svg',
                          content:'Até à</br> próxima!',
                          click:'function(){set_screen("return_iRave")}',
                          callback: 'function(){delete_ride();}'
                        },
                      bar:
                        { type:'uni',
                          array:[ {logo:"./assets/icons/ok.svg", style:"bar-color_blue_circle_uni", click:'function(){set_screen("return_iRave")}'} ]
                        }
                      },

  "return_iRave":{screen:
                      { type:'dynamic_info',
                        title:'',
                        image:'./assets/icons/iRave.png',
                        content:'Devolva',
                        next_up: ["iRave","Devolva","iRave","iRave","Devolva","iRave","Devolva","iRave","Devolva"],
                        callback: 'function(){rotate_content();lock_screen()}',
                      },
                    bar:
                      { type:'uni',
                        array:[{logo:"./assets/icons/cancel.svg", style:"bar-color_blue_circle_uni", click: "restore_last_screen"} ]

                      }
                    },

        "ask_edit_food_screen":{screen:
                        {type:"slider_menu",
                        views:[{title:"Editar","logo":"./assets/icons/edit.svg",label:"Encomenda",id:"edit"},
                               {title:"Cancelar","logo":"./assets/icons/cancel.svg",label:"Encomenda",id:"cancel"},
                               {title:"Nova","logo":"./assets/icons/fast_food.svg",label:"Encomenda",id:"new"},],
                               click:"function(){c = get_slider_selected_id(); if (c=='new') {new_food_order(); set_screen(json_gen_restaurants());} else if (c=='edit') {set_screen('food_screen')} else {discard_food_order();go_to_first_screen_and_discard()}}"},
                       bar:
                        {type:"double",
                         array:[{"logo":"./assets/icons/undo.svg","style":"bar-color_yellow","click":"restore_last_screen"},
                                {"logo":"./assets/icons/ok.svg","style":"bar-color_green","click":"function(){c = get_slider_selected_id(); if (c=='new') {new_food_order(); set_screen(json_gen_restaurants());} else if (c=='edit') {set_screen('food_screen')} else {discard_food_order();go_to_first_screen_and_discard()}}"}]
                        }
                      },
        "food_screen":{screen:
                        {type:"slider_menu",
                        views:[{title:"","logo":"./assets/icons/drink.svg",label:"Bebidas",id:"drinks"},
                               {title:"","logo":"./assets/icons/snack.svg",label:"Snacks",id:"snacks"},
                               {title:"","logo":"./assets/icons/fast_food.svg",label:"Menus",id:"menus"}],
                               click:"function(){Cookies.set('food_type',get_slider_selected_id());set_screen(json_gen_food(Cookies.get('food_type'),Cookies.get('restaurant')));}"},
                       bar:
                        {type:"double",
                         array:[{"logo":"./assets/icons/undo.svg","style":"bar-color_yellow","click":"restore_last_screen"},
                                {"logo":"./assets/icons/ok.svg","style":"bar-color_green","click":"function(){Cookies.set('food_type',get_slider_selected_id());set_screen(json_gen_food(Cookies.get('food_type'),Cookies.get('restaurant')));}"}]
                        }
                      },
         "food_cancel_order":{screen:
                             { type:'info',
                               title:'Cancelar',
                               image:'',
                               content:'Encomenda?',
                            },
                           bar:
                             { type:'double',
                               array:[ {logo:"./assets/icons/ok.svg", style:"bar-color_red", click:'function(){go_to_first_screen_and_discard();discard_food_order()}' },
                                       {logo:"./assets/icons/cancel.svg", style:"bar-color_green", click:'function(){set_screen("food_screen");}'}, ]
                             }
                           },
         "food_order_almost_arrived":{screen:
                             { type:'dynamic_info',
                               title:'Encomenda',
                               image:'./assets/icons/destination_path.svg',
                               content:'Está quase</br> pronta',
                               next_up: ['Siga a</br> Bússula','Para chegar </br>ao local'],
                               callback: 'rotate_content',
                               click:'function(){set_screen("navigator")}',
                             },
                           bar:
                             { type:'double',
                               array:[ {logo:"./assets/icons/cancel.svg", style:"bar-color_red", click:'function(){set_screen("want_to_go_on_your_own_food")}'},
                                       {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){set_screen("navigator")}'} ]
                             }
                           },


        // navigator for food menu
         "navigator":{screen:
                             { type:'navigator',
                               title:'Navigator',
                               image:'./assets/icons/navigation.svg',
                               content:'35 passos',
                               callback:'function(){navigate(),update_navigator(0)}'
                            },
                           bar:
                             { type:'uni',
                               array:[ {logo:"./assets/icons/cancel.svg", style:"bar-color_blue_circle_uni", click:'function(){clear_path_timeouts();set_screen("want_to_go_on_your_own_food");}' },
                             /*{logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){set_screen("food_collect_food");clear_path_timeouts();}'},*/ ]
                             }
                           },

         // in case the person wants to go by their own
         // this way we can show the ticket number after
         "want_to_go_on_your_own_food":{screen:
                             { type:'info',
                               title:'Consigo',
                               image:'./assets/icons/destination_path.svg',
                               content:'ir sozinha(o)',
                               click:'function(){set_screen("food_collect_food")}',
                             },
                           bar:
                             { type:'double',
                               array:[{logo:"./assets/icons/cancel.svg", style:"bar-color_red", click:'function(){set_screen("navigator")}'},
                                      {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){set_screen("food_collect_food")}'}]
                             }
                           },


         "navigator_dest_reached":{screen:
                             { type:'info',
                               title:'Chegou',
                               image:'./assets/icons/destination.svg',
                               content:'ao </br> Destino',
                            },
                           bar:
                             { type:'uni',
                               array:[ {logo:"./assets/icons/ok.svg", style:"bar-color_blue_circle_uni", click:'function(){set_screen(Cookies.get("when-arrived-at-dest"))}'}, ]
                             }
                           },

         "food_collect_food":{screen:
                             { type:'dynamic_info',
                               title:'Pedido nº',
                               image:'./assets/icons/number.svg',
                               content:'Levante o </br> seu pedido',
                               next_up: ['Peça o numero </br> indicado','Levante o </br> seu pedido'],
                               callback: 'rotate_content',
                               click:'function(){discard_food_order();go_to_first_screen_and_discard();}',
                            },
                           bar:
                             { type:'uni',
                               array:[ /*{logo:"", style:"bar-top-disabled"},*/
                                       {logo:"./assets/icons/ok.svg", style:"bar-color_blue_circle_uni", click:'function(){discard_food_order();go_to_first_screen_and_discard()}'}, ]
                             }
                           },


          // FRIENDS RELATED SCREENS

         "friends_screen":{screen:
                            {type:"slider_menu",
                            views:[{title:"","logo":"./assets/icons/list-users.svg",label:"Lista de Amigos",id:"list_friend"},
                            {title:"","logo":"./assets/icons/add-friend.svg",label:"Adicionar Amigo",id:"add_friend"},
                            {title:"","logo":"./assets/icons/remove-friend.svg",label:"Remover Amigo",id:"remove_friend"}],
                            click:'click_on_friend_menu',
                            callback:'function(){if (get_friends().length===0) {restore_last_screen();set_screen("friends_screen_no_friends")}}',
                          },
                          bar:
                            {type:"double",
                              array:[{"logo":"./assets/icons/undo.svg","style":"bar-color_yellow","click":"restore_last_screen"},
                                    {"logo":"./assets/icons/ok.svg", style:"bar-color_green", click:'click_on_friend_menu'}]
                            }
                          },

          // for when there are no friends
         "friends_screen_no_friends":{screen:
                            {type:"slider_menu",
                            views:[/*{title:"","logo":"./assets/icons/list-users.svg",label:"Lista de Amigos",id:"list_friend"},*/
                            {title:"","logo":"./assets/icons/add-friend.svg",label:"Adicionar Amigo",id:"add_friend"},
                            {title:"","logo":"./assets/icons/remove-friend_disabled.svg",label:"Remover Amigo",id:""}],
                            click:'click_on_friend_menu',
                          },
                          bar:
                            {type:"double",
                              array:[{"logo":"./assets/icons/undo.svg","style":"bar-color_yellow","click":"restore_last_screen"},
                                    {"logo":"./assets/icons/ok.svg", style:"bar-color_green", click:'click_on_friend_menu'}]
                            }
                          },
          "friends_selected_confirm":{screen:
                               { type:'dynamic_info',
                                 title:'FIRIENDSDS',
                                 image:'./assets/icons/security_man.svg',
                                 content:'Ação não pode ser cancelada',
                                 next_up: ['Chamar Seguranças?'],
                                 callback: 'rotate_content'
                               },
                             bar:
                               { type:'double',
                                 array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:'restore_last_screen'},
                                         {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:'function(){set_screen("security_call")}'} ]
                               }
                             },

}

function load_to_local_storage() {
    for(var screen in config_dict) {
        localStorage.setItem(screen, JSON.stringify(config_dict[screen]));
    }
}

load_to_local_storage()


function click_on_main_menu(){
  var c=get_slider_selected_id();
  if (c=="food_choose_restaurant")
    if(food_order_exists())
      set_screen("ask_edit_food_screen")
    else
      set_screen(json_gen_restaurants());
  else if (c=="leave_screen")
    if (pending_ride())
      set_screen("pending_ride")
    else
      set_screen("leave_screen")
  else if(c=="friends_screen" && Cookies.get("emparelhado") !== "true")
      set_screen(consents_screens['get_consent_contacts'])
  else
    set_screen(c);
}

function wants_friends_screen(){
  if(Cookies.get("emparelhado") !== "true")
    set_screen(consents_screens['get_consent_contacts'])
  else
    set_screen("friends_screen")
}

function click_on_friend_menu(){
  var c=get_slider_selected_id();
  if (c=="list_friend")
    set_screen(json_gen_friends());
  else if(c=="friends_screen" && Cookies.get("emparelhado") !== "true")
      set_screen(consents_screens['get_consent_contacts'])
  else if (c=="add_friend")
    set_screen(connect_friend_screens['1st_step'])
  else if (c=="remove_friend")
    set_screen(json_gen_remove_friends());
}

function click_on_leave_screen(){
  console.log("click_on_leave_screen")
  if (pending_ride())
    set_screen("pending_ride")
  else
    set_screen("leave_screen")

}

function click_on_piggyback_accept_ride(){
  if (pending_ride())
    set_screen("pending_ride")
  else
    set_screen("piggyback_accept_ride_confirm")
}
