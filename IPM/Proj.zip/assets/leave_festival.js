//ammount = 5;
ride = {}

function pending_ride(){
  return !jQuery.isEmptyObject(ride);
}

function set_ride(ride_type, notification) {
  ride["type"] = ride_type;
  ride["notification"] = notification;
}

function delete_ride() {ride = {};}
function cancel_ride(){
  console.log("NOTIFICATION")
  clearTimeout(ride["notification"]["timeout"])
  ride = {}
  show_all_in_table()
}

function decrease_info_quantity(){
  set_current_ammount(get_current_ammount()-5)
  set_ammount_selector_ammount("",get_current_ammount(),"</br> minutos")
}

function increase_info_quantity(){
  set_current_ammount(get_current_ammount()+5)
  set_ammount_selector_ammount("",get_current_ammount(),"</br> minutos")
}


function set_ammount_selector_info_ammount(amm){
  $("#info-content").children(":first").html(amm+"</br> minutos")
}


function exit_festival_listen() {
 ammount = 5
 set_ammount_selector_info_ammount(ammount)

}


//TODO: generalize also for rides (boleias)
//TODO: also make the same thing for food
//TODO: offer to cancel food orders (?)
//TODO: add info screen to show what is blocking
function check_if_can_exit_festival() {

  // Prepares notification array to be queried
  cleanup_array()
  // Calculate selected date
  var d = new Date(new Date().getTime() + get_current_ammount()*60*1000)

  //See if we have anything after
  var problematic = notification_array.filter(is_future_event_or_exit, {date:d})

  if(problematic.length > 0) {
    var warning;
    var min_to_go = Math.ceil( (problematic[0].time -  new Date())/(60*1000) )
    if(ride_regex.test(problematic[0].name)){
      // Offer to reschedule ride
      warning = "Já tem saída marcada daqui a " +  min_to_go + " min"
    } else {
      warning = "Não pode sair antes da sua comida (faltam "+ min_to_go +" min)"
    }


    var json= {screen:
                { type:'info',
                  title:'Atenção',
                  content: warning,
                },
              bar:
                { type:'uni',
                  array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_blue", click:restore_last_screen }]
                }
              };

    set_screen(json)
  } else {
    set_screen('ride_confirm')
  }

}

// Should catch all types of rides
var ride_regex = new RegExp(" ride")
function is_future_event_or_exit(el){
  var current_date = this.date

  if(el.time > this.date || ride_regex.test(el.name))
    return true
  else
    return false

}
