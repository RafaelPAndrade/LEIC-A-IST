/* Friend functionality */

/* GLOBALS */
var selected_friends = [];
var friends_ordered = []; // used to obtain the final list of friends selected


// JSON that is the contacts taken from the phone

var friends_in_contacts = {
'912345678': 'Ana Silva',
'938765432': 'João Pereira',
'920101001': 'Joana Macieira',
'934012345': 'Carlos Oliveira'
}




var friends_added = []
function reset_friends(){
  friends_added = []
}

function add_friend(new_name, new_number){
  if(-1 === friend_is_already_added(new_number))
    friends_added.push({name:new_name, number:new_number})
}

function remove_friend(number){
  var n = friend_is_already_added(number)
  if(n> -1)
    friends_added.splice(n,1)
}

function get_friends(){
  function cmp(n1,n2) {
    return ( ( n1.name === n2.name ) ? 0 : ( ( n1.name > n2.name ) ? 1 : -1 ) );
  }
  friends_added.sort(cmp)
  return friends_added;
}

function get_friend_name_from_number(number){
  return friends_in_contacts[number]
}

function friend_is_already_added(number){
  for(var i=0; i < friends_added.length; ++i){
    if(number === friends_added[i].number)
      return i;
  }

  return -1;
}


// Below are the screens needed

var consents_screens = {
'get_consent_contacts':{screen:
                         {type:'info',
                          title: 'Atenção',
                          content:'Emparelhar iRave com telefone?',
                          click:function(){set_screen(consents_screens['1st_step']);},
                         },
                         bar:
                          { type:'double',
                            array:[{logo:"./assets/icons/cancel.svg", style:"bar-color_red",click:function(){restore_last_screen();Cookies.set('emparelhado','false');}},
                                   {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:function(){set_screen(consents_screens['1st_step']);}}, ]
                          }
                        },

'1st_step':{screen:
             {type:'info',
              title: '1ᵒ passo',
              content:'Ligue o bluetooth no seu telefone',
              click:function(){set_screen(consents_screens['2nd_step']);},
             },
             bar:
             {type:"triple",
               array:[{logo:"./assets/icons/cancel.svg",style:"bar-color_blue_circle",click:function(){restore_last_nth_screen(1)}  },
                      {logo:"./assets/icons/undo.svg", style:"bar-color_blue_circle", click:restore_last_screen },
                      {logo:"./assets/icons/ok.svg",style:"bar-color_blue_circle",click:function(){set_screen(consents_screens['2nd_step']);}} ]
             }
           },
'2nd_step':{screen:
               {type:'info',
                title: '2ᵒ passo',
                content:'Selecione o dispositivo iRave-<b><span id="irave-id">1234</span></b> para emparelhar',
                click:function(){set_screen(consents_screens['3rd_step']);},
               },
            bar:
             {type:"triple",
               array:[{logo:"./assets/icons/cancel.svg",style:"bar-color_blue_circle",click:function(){restore_last_nth_screen(2)}  },
                      {logo:"./assets/icons/undo.svg", style:"bar-color_blue_circle", click:restore_last_screen },
                      {logo:"./assets/icons/ok.svg",style:"bar-color_blue_circle",click:function(){set_screen(consents_screens['3rd_step']);}} ]
             }
           },
'3rd_step':{screen:
               {type:'info',
                title: '3ᵒ passo',
                content:'Insira o </br> código</br> <b>1426</b>',
                click:function(){set_screen(consents_screens['done']);},
               },
               bar:
             {type:"triple",
               array:[{logo:"./assets/icons/cancel.svg",style:"bar-color_blue_circle",click:function(){restore_last_nth_screen(3)}  },
                      {logo:"./assets/icons/undo.svg", style:"bar-color_blue_circle", click:restore_last_screen },
                      {logo:"./assets/icons/ok.svg",style:"bar-color_blue_circle",click:function(){set_screen(consents_screens['done']);}} ]
             }
              },

'done':{screen:
               {type:'info',
                title: 'Já está',
                content:'Agora pode adicionar ou remover os seus amigos',
                click:function(){Cookies.set('emparelhado','true');restore_last_nth_screen(5);set_screen('friends_screen');},
               },
               bar:
                {type:'uni',
                  array:[{logo:"./assets/icons/ok.svg",style:"bar-color_blue_circle_uni",click:function(){Cookies.set('emparelhado','true');restore_last_nth_screen(5);set_screen('friends_screen');}}]
                }
              },
}


connect_friend_screens = {
'1st_step':{screen:
             {type:'info',
              title: '1ᵒ passo',
              content:'Preparem os iRave',
              click:function(){set_screen(connect_friend_screens['2nd_step']);},
             },
             bar:
             {type:"triple",
               array:[{logo:"./assets/icons/cancel.svg",style:"bar-color_blue_circle",click:function(){restore_last_nth_screen(1)}  },
                      {logo:"./assets/icons/undo.svg", style:"bar-color_blue_circle", click:restore_last_screen },
                      {logo:"./assets/icons/ok.svg",style:"bar-color_blue_circle",click:function(){set_screen(connect_friend_screens['2nd_step']);}} ]
             }
           },
'2nd_step':{screen:
             {type:'info',
              title: '2ᵒ passo',
              image: './assets/icons/nfc-sign-white.png',
              content:'Aproximem os iRave',
              callback:friend_get_random_friend
             },
             bar:
             {type:"double",
               array:[{logo:"./assets/icons/cancel.svg",style:"bar-color_red",click:function(){restore_last_nth_screen(2)}  },
                      {logo:"./assets/icons/undo.svg", style:"bar-color_green", click:restore_last_screen },]
             }
           },


}

function friend_get_random_friend(){

  var not_choosen = Object.keys(friends_in_contacts).filter(function(number){return -1 === friend_is_already_added(number)})

  var n = not_choosen.length
  var number = not_choosen[Math.floor(Math.random()*n)]

  var name = get_friend_name_from_number(number)


  var json;

  if(n > 0 && number !== undefined) {
   json = {
    screen:
      {
      type: 'info',
      title: 'Adicionar',
      content: String.format('{0}<br>({1})?', name, number)
      },
      bar:
      {
      type:'double',
      array:[{logo:"./assets/icons/cancel.svg", style:"bar-color_red",click:function(){restore_last_nth_screen(3)}},
             {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:function(){add_friend(name,number);restore_last_nth_screen(4);set_screen("friends_screen")}}, ]
      }
    }
  } else {
   json = {
    screen:
      {
      type: 'info',
      title: 'Atenção',
      content: 'Nenhum amigo detetado'
      },
      bar:
      {
      type:'uni',
      array:[{logo:"./assets/icons/undo.svg", style:"bar-color_blue_circle_uni",click:function(){restore_last_nth_screen(3)}}]
      }
    }

  }


  // TODO: add some jitter time here?
  build_notification(4000, "Pairing friend", json,"no info", "friends");
}


/* for selecting friends in the toggle menu for removal*/
function json_gen_remove_friends(){
  selected_friends = [];
  friends_ordered = [];

  var friends = get_friends();
  var views = [];

  var add_letter = function(){
    for (var f in friends)
        $("#" + friends[f].number + " .slider_menu-logo").css("font-size","1.5cm").html(friends[f].name[0].toUpperCase())
  }

  /*TODO add confirmation screen here*/
  var remove_friends = function(){
    get_selected_items().filter(function(el){return el !== undefined}).forEach(function(i){remove_friend(friends_ordered[i])});
    restore_last_nth_screen(2);set_screen("friends_screen");
  }

  for (var f in friends) {
    views.push({title: friends[f].name, label:friends[f].number, id:friends[f].number})
    friends_ordered.push(friends[f].number)
  }

  var json = { screen:
               {type:"slider_menu_toggle",
                onrestore:"confirm_go_back",
                views: views,
                click: function(){toggle_slider_menu_item()},
                callback: function(){slider_menu_toggle_init();add_letter()},
                cleanup:function(){gen_selected_friends()}
               },
               bar:
               { type:'double',
                 array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:restore_last_screen},
                         {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:remove_friends } ]
               }
            }

  return json;
}


function json_gen_friends(){

  var friends = get_friends();
  var views = [];

  var c = function(){
    for (var f in friends)
        $("#" + f + " .slider_menu-logo").css("font-size","1.5cm").html(friends[f].name[0].toUpperCase())
  }


  for (var friend in friends) {
    friends_ordered.push
    views.push({title:friends[friend]['name'], label:friends[friend]['number'], id:friend})
  }

  var json = { screen:
               {type:"slider_menu",
                onrestore:"confirm_go_back",
                views: views,
                callback: c
               },
               bar:
                 {type:"uni",
                 array:[{logo:"./assets/icons/undo.svg","style":"bar-color_blue_circle_uni","click":restore_last_screen}]
              }
            }

  return json;
}

function gen_selected_friends() {
  sel_items = get_selected_items();
  console.log("printing selected friends")
  for (var i in sel_items) {
    console.log(sel_items[i]+" "+friends_ordered[sel_items[i]])
    selected_friends.push(friends_ordered[sel_items[i]])
  }
}

/* for selecting friends in the toggle menu */
function json_gen_select_friends(){
  selected_friends = [];
  friends_ordered = [];

  var friends = get_friends();
  var views = [];

  var add_letter = function(){
    for (var f in friends)
        $("#" + friends[f].number + " .slider_menu-logo").css("font-size","1.5cm").html(friends[f].name[0].toUpperCase())
  }


  for (var f in friends) {
    views.push({title: friends[f].name, label:friends[f].number, id:friends[f].number})
    friends_ordered.push(friends[f].number)
  }

  var json = { screen:
               {type:"slider_menu_toggle",
                onrestore:"confirm_go_back",
                views: views,
                click: function(){toggle_slider_menu_item()},
                callback: function(){slider_menu_toggle_init();add_letter()},
                cleanup:function(){gen_selected_friends()}
               },
               bar:
               { type:'double',
                 array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:restore_last_screen},
                         {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:function(){set_screen("piggyback_ride_time_select")} } ]
               }
            }

  return json;
}
