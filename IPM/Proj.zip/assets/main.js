var cache={};
var function_regex = new RegExp('function()')


function refresh_cache(specname){
  var spec = JSON.parse(localStorage.getItem(specname))
  spec = recursive_descent(spec, get_func_from_description)
  cache[specname] = spec
}

function get_func_from_description(desc){
    if(window.hasOwnProperty(desc) && typeof window[desc] === "function") {
      return window[desc]
    } else if(function_regex.test(desc)) {
      return eval('(' + desc + ')')
    } else {
      console.log('Failed to get function ' + desc)
      return 0;
    }
}

function recursive_descent(json_spec, func){
    for (var i in json_spec) {
      if(i==='click' || i==='callback' || i==='cleanup' || i==='onrestore') {
        json_spec[i] = func(json_spec[i]);
      } else if (json_spec[i] !== null && typeof(json_spec[i])==="object") {
            recursive_descent(json_spec[i], func);
      }
    }
    return json_spec
}

function get_spec_by_name(specname){
  if(!cache.hasOwnProperty(specname)){
    var spec = JSON.parse(localStorage.getItem(specname))
    spec = recursive_descent(spec, get_func_from_description)
    cache[specname] = spec
  }

  return cache[specname]
}


var cleanup_function;
var previous_onrestore;

function set_screen(spec){
  telemetry_func_called(arguments.callee.name);
  console.log("settting screen "+spec)

  if(typeof cleanup_function === "function"){
    cleanup_function.call()
  }

  if(typeof spec === "string"){
    spec = get_spec_by_name(spec)
  }

  var $screen, $bar
  switch(spec.screen.type){
    case "main_screen":
      $screen = construct_main_screen(spec.screen);
      break;
    case "slider_menu":
      $screen = construct_slider_menu(spec.screen);
      break;
    case "slider_menu_ammount":
      $screen = construct_slider_menu_ammount(spec.screen);
      break;
    case "slider_menu_toggle":
      $screen = construct_slider_menu_toggle(spec.screen);
      break;
    case "info_menu_ammount":
      $screen = construct_info_menu_ammount(spec.screen);
      break;
    case "info":
      $screen = construct_info_screen(spec.screen);
      break;
    case "dynamic_info":
      $screen = construct_dynamic_info_screen(spec.screen);
      break;
    case "navigator":
      $screen = construct_navigator_screen(spec.screen);
      break;
    default:
      console.log("Error: " + spec.screen.type + " not defined")
  }

  console.log("processing bar "+spec.bar.type)
  switch(spec.bar.type){
    case "triple":
    case "double":
    case "uni":
      $bar = n_side_bar(spec.bar);
      break;
    default:
      console.log("Error: " + spec.bar.type + " not defined")
  }

  // To handle a intermediary function before poping the screen back
  // and also having a cleanup the next time I go to the next screen
  set_and_save_current_screen($screen, $bar, previous_onrestore, cleanup_function)
  previous_onrestore = spec.screen.onrestore

  // To handle post-initialization
  switch(spec.screen.type){
    // This is to immediately refresh the carousel
    case "slider_menu":
      $('#menu').owlCarousel().trigger('refresh.owl.carousel');
    default:
      if(typeof spec.screen.callback === "function"){
        spec.screen.callback()
      }
  }

  fit_all_text()

  // To set any necessary on exit cleanups (timers, for example)
  if(typeof spec.screen.cleanup === "function") {
    cleanup_function = spec.screen.cleanup
  } else {
    switch(spec.screen.type){
      case "dynamic_info":
        cleanup_function = clear_screen_timers;
        break;
      default:
        cleanup_function = undefined;
    }
  }

}

var screens_stack = []

function set_and_save_current_screen($new_screen, $new_bar, onrestore_func, cleanup_func){
  screens_stack.push({screen:$("#main_screen").detach(),
                      bar:$("#slide_bar").clone(true),
                      onrestore: onrestore_func,
                      cleanup: cleanup_func
                     });

  $new_screen.appendTo(".touch-screen")
  $("#slide_bar").replaceWith($new_bar)
}


function put_new_screen($screen, $bar) {
    $('#main_screen').replaceWith($screen)
    $("#slide_bar").replaceWith($bar)
}

function put_back_stack_element(el) {
  screens_stack.push(el)
}

function restore_stack_element(el) {
  if(el !== undefined) {
    // Cleanup current screen
    if(typeof cleanup_function === "function"){
      cleanup_function.call()
    }
    el.use_this = true
    if(typeof el.onrestore === 'function') {
      el.onrestore.call(el)
    }
    if(el.use_this === true){
      put_new_screen(el.screen, el.bar);
      // Setting globals to be used by set_screen
      previous_onrestore = el.onrestore;
      cleanup_function = el.cleanup;
    }
  }
}


function restore_last_screen(){
  telemetry_func_called(arguments.callee.name);


  restore_stack_element(screens_stack.pop())
}

function restore_last_nth_screen(nth){
  for(i=0;i<nth;++i)
    restore_stack_element(screens_stack.pop())
}

function go_to_first_screen_and_discard(){
  restore_stack_element(screens_stack.shift())
  // Discarding
  screens_stack = []
}


function init_simulation(){
  set_screen('initial_screen')
  // Delete all cookies
  Object.keys(Cookies.get()).forEach(function(cookieName) {
    Cookies.remove(cookieName);
  });
  delete_all_notifications()
  screens_stack = []
  food_listed = []
  old_food_orders = []
  current_food_order = {}

}


init_simulation();
