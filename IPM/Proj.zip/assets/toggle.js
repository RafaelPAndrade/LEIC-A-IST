var selected_item = 0;
var selected_items = [];

function slider_menu_toggle_init(){
  slider_menu_toggle_listen();
  update_ok_button_toggle();
  selected_item = 0;
  selected_items = [];
}



function slider_menu_toggle_listen() {
 $('.owl-carousel').on('changed.owl.carousel', function(e) {

   // NOTE: get_slider_selected_id was not working so we access trough the indexes
   console.log("now selected "+e.item.index)
   selected_item = e.item.index
   update_ok_button_toggle();
 });
}

/* returns the truth value of whether or not the element is toggled */
function toggled(element){
  for (var i in selected_items) if (selected_items[i]===element) return true;
  return false;
  //return selected_items.hasOwnProperty(element)
}

function get_selected_items(){
  return selected_items;
}



function update_ok_button_toggle(){
  if (jQuery.isEmptyObject(selected_items)){
    $("#btn1_icon").css("opacity","0.6");
    /* TODO  CURRENTLY NOT WORKING TODO
    // disabling the button code
    var command = $("#btn1_icon").attr("onclick")
    if (command.indexOf("return;")==0) { // if it is already disabled
      command = command.substring("return;".length)
    }
    $("#btn1_icon").attr("onclick",command)
    */
  }
  else {
    $("#btn1_icon").css("opacity","1.0")
    /* TODO CURRENTLY NOT WORKING TODO
    // enabling the button code
    var command = $("#btn1_icon").attr("onclick")
    command = "return;"+command
    $("#btn1_icon").attr("onclick",command)
    */
  }
}

function toggle_slider_menu_item(){
  if (toggled(selected_item)) {
    delete selected_items[selected_items.indexOf(selected_item)]
    $("#check_"+selected_item).attr({"src": "./assets/icons/unchecked.svg"});
  } else {
    selected_items.push(selected_item)
    $("#check_"+selected_item).attr({"src": "./assets/icons/checked.svg"});
  }
  update_ok_button_toggle()
  console.log(selected_items)
}

function enable_check_toggles(){
  for(let i=0; i<number_of_toggles; ++i) {
    $("#check_"+i).toggle(
      function(){$("#check_"+i).attr({"src": "./assets/icons/unchecked.svg"});console.log("toggled");},
      function(){$("#check_"+i).attr({"src": "./assets/icons/checked.svg"});console.log("toggled");},
    );
  }
}
