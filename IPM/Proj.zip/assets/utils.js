// Here are the functions that are used somewhere on click events on the
// screens, and for it to be valid JSON it must be loaded first

//Screen drawing

/* Main screen */

function construct_main_screen(screen_spec) {

  var html;
  html  = '<div id="main_screen">'
  html += '<div id="clock" class="horizontal-center"><span id="clock_h"></span><span id="clock_dots">:</span><span id="clock_m"></span></div>'
  html += '<div id="main_screen-text">'
  html += '<div id="main_screen-band" class="horizontal-center fit-text">' + screen_spec.band + '</div>'
  html += '<div id="main_screen-song" class="horizontal-center fit-text">' + screen_spec.song + '</div>'
  html += '</div></div>'


  return $(html).click(screen_spec.click)
}

/* Base info screen */
function construct_info_screen(screen_spec) {

  var html;
  html  = '<div id="main_screen">'
  html += '<div id="info-title" class="horizontal-center fit-text">' + screen_spec.title + '</div>'
  if (screen_spec.hasOwnProperty("image") && screen_spec.image !== undefined && screen_spec.image !== '') {
    html += '<div id="info-logo" class="horizontal-center ">' + image_wrap(screen_spec.image) + '</div>'
    html += '<div id="info-content" class="fit-text horizontal-center ">' + screen_spec.content + '</div>'
  } else {
    html += '<div id="info-content" class="no-logo fit-text horizontal-center "><div class="ammount_selected">' + screen_spec.content + '</div></div>'
  }

  return $(html).click(screen_spec.click)
}




var screen_timer = [];
var next_screen = [];

function swap_content(new_string){

  var $container = $('#info-content')

  $container.fadeOut(400, function(){
                            $container.html(new_string)
                                      .css({'opacity':'0','display':''})
                                      .children().css('display','inherit');
                            textFit($container[0],
                              {multiLine:true, alignHoriz:true, alignVert:true,
                               alignVertWithFlexbox:true, maxFontSize:20
                              });
                            $container.css({'opacity':'', 'display':'none'})
                                      .children().css({'display':''})
                            $container.fadeIn(400, rotate_content);
                          }
                    )


}

function rotate_content(){

  if( $("#info-content").length!==0 && next_screen.length!==0){
    screen_timer.push(setTimeout(swap_content, 1500, next_screen.shift()));
  }
}

function clear_screen_timers(){
  var container = $('#info-content')[0]
  clearTimeout.apply(null, screen_timer);
  screen_timer = [];
  $(container).stop()
}

function construct_dynamic_info_screen(screen_spec){

  next_screen = screen_spec.next_up.slice();
  screen_timer = [];
  return construct_info_screen(screen_spec);

}

/* Navigation screen allows a person to navigate to a destination */

function construct_navigator_screen(screen_spec){
    var html;
    html  = '<div id="main_screen">'
    html += '<div id="info-title" class="horizontal-center fit-text">' + screen_spec.title + '</div>'
    /*html += '<div id="navigation_path">\
              <img id="path_top" src="./assets/icons/path.svg"></img>\
              <img id="path_bottom" src="./assets/icons/path.svg"></img>\
             </div>'*/
    html += '<div id="info-logo" class="horizontal-center ">'
        + '<img id="navigator_image" class="image horizontal-center" src="./assets/icons/navigation.svg"/></img>' + '</div>'
    html += '<div id="info-content" class="fit-text horizontal-center ">' + screen_spec.content + '</div>'


    return $(html).click(screen_spec.click)
}

function construct_slider_menu(screen_spec) {

  var $html, temp;
  $html  = $('<div style="owl-carousel owl-theme" id="menu"></div>')
  for(let i=0; i<screen_spec.views.length; ++i) {
    temp  = '<div id="'+ screen_spec.views[i].id +'" style="height:100%;">'
    temp += '<div class="slider_menu-title fit-text horizontal-center">'+screen_spec.views[i].title+'</div>'
    if (screen_spec.views[i].logo !== '') {
      temp += '<div class="$ammount_selector slider_menu-logo horizontal-center ">' + image_wrap(screen_spec.views[i].logo) + '</div>'
      temp += '<div class="slider_menu-label fit-text horizontal-center ">' + screen_spec.views[i].label + '</div>'
    } else {
      temp += '<div class="slider_menu-label no-logo fit-text horizontal-center ">' + screen_spec.views[i].label + '</div>'
    }
    temp += '</div>'
    $html.append($(temp).click(screen_spec.click))
  }

  $html.addClass("owl-carousel owl-theme")
       .owlCarousel({items:1})

  return $('<div id="main_screen"></div>').append($html)
}

number_of_toggles=1;

function construct_slider_menu_toggle(screen_spec) {
  number_of_toggles = screen_spec.views.length;
  var $html, temp;
  $html  = $('<div style="owl-carousel owl-theme" id="menu"></div>')
  for(let i=0; i<screen_spec.views.length; ++i) {
    temp  = '<div id="'+ screen_spec.views[i].id +'" style="height:100%;">'
    temp += '<img id="check_'+i+'" class="toggle" src="./assets/icons/unchecked.svg">'
    temp += '<div class="slider_menu-title fit-text horizontal-center">'+screen_spec.views[i].title+'</div>'
    if (screen_spec.views[i].logo !== '') {
      temp += '<div class="$ammount_selector slider_menu-logo horizontal-center ">' + image_wrap(screen_spec.views[i].logo) + '</div>'
      temp += '<div class="slider_menu-label fit-text horizontal-center ">' + screen_spec.views[i].label + '</div>'
    } else {
      temp += '<div class="slider_menu-label no-logo fit-text horizontal-center ">' + screen_spec.views[i].label + '</div>'
    }
    temp += '</div>'
    $html.append($(temp).click(screen_spec.click))
  }

  $html.addClass("owl-carousel owl-theme")
       .owlCarousel({items:1})

  return $('<div id="main_screen"></div>').append($html)
}



/* allows for the selection of the number of items of each view */
function construct_slider_menu_ammount(screen_spec) {

    var $html, $ammount_selector;

    $html = construct_slider_menu(screen_spec).css('height', '3.1cm').css('border-radius','2mm 0 0 0mm')

    $ammount_selector = $('<div class="ammount-selector"></div>')
    $ammount_selector.append('<div onclick="decrease()" id="decrease" class="selector_left" ><img id="negative" src="./assets/icons/negative_disabled.svg"></div>')
    $ammount_selector.append('<div class="ammount_selected selector_center" >0<div>')
    $ammount_selector.append('<div onclick="increase()" id="increase" class="selector_right" ><img id="positive" src="./assets/icons/plus.svg"></div>')

    return $html.append($ammount_selector)
}

/* allows for the selection of the number of items */
function construct_info_menu_ammount(screen_spec) {

    var $html, $ammount_selector;

    $html = construct_info_screen(screen_spec).css('height', '3.1cm').css('border-radius','2mm 0 0 0mm')

    $ammount_selector = $('<div class="ammount-selector"></div>')
    $ammount_selector.append('<div onclick="decrease()" id="decrease" class="selector_left" ><img id="negative" src="./assets/icons/negative_disabled.svg"></div>')
    //$ammount_selector.append('<div id="ammount_selected" class="selector_center" >0<div>')
    $ammount_selector.append('<div onclick="increase()" id="increase" class="selector_right" ><img id="positive" src="./assets/icons/plus.svg"></div>')

    return $html.append($ammount_selector)
}

// Side or slide bar drawing

function n_side_bar(bar_spec) {

  var $html, $btn, css, center_type;

  $html = $('<div id="slide_bar" class="slide-bar"></div>')

  switch(bar_spec.type){
    case "triple":
      css='third-height';
      center_type='triple-side-bar-center';
      break;
    case "double":
      css='half-height';
      center_type="";
      break
    case "uni":
      css='full-height';
      center_type="uni-side-bar-center";
      break
  }
  var i;
  for(i=0; i<bar_spec.array.length; ++i) {
    $btn  = $('<div class="slide-bar '+css+'" id="btn'+i+'"></div>')
          .addClass(bar_spec.array[i].style)
          .html('<div id="btn'+i+'_icon" class="'+center_type+'">'+image_wrap(bar_spec.array[i].logo)+'</div>')
          .click(bar_spec.array[i].click)
    if (i===0) $btn.addClass("bar-top")
    $html.append($btn)
  }
  $btn.addClass("bar-bottom")


  return $html
}


// Misc functions

//Main screen functions

function unlock_screen(){
  $("#main_screen").animate({width:"25mm",
                            borderTopRightRadius: "0mm",
                            borderBottomRightRadius: "0mm"})

}

function lock_screen(){
  $("#main_screen").animate({width:"31mm",
                             borderTopRightRadius: "2mm",
                             borderBottomRightRadius: "2mm"})
}

show_clock_dots = false;
function update_time(){
  let d = new Date()
  $("#clock_dots").css('opacity',+show_clock_dots);
  show_clock_dots = !show_clock_dots;
  $("#clock_h").html(leftpad_str(d.getHours()));
  $("#clock_m").html(leftpad_str(d.getMinutes()));
  screen_timer.shift(); // Take away first timer (last update time)
  screen_timer.unshift(setTimeout(update_time, 700));
}

// Slide bar function to get selected id

function get_slider_selected_id(){
  return $(".owl-carousel .owl-item.active").children(":first").attr("id")
}


/* Random */

// Image wrapper
function image_wrap(name){
  if(name != undefined && name != '')
    return '<img id="image" class="image horizontal-center" src="'+name+'"/></img>'
  else
    return ''
}

// Applies textFit to all elements that have a css class named "fit-text"
function fit_all_text(){
  textFit($(".fit-text"),
          {multiLine:true, alignHoriz:true, alignVert:true,
           alignVertWithFlexbox:true, maxFontSize:20});
}

function leftpad_str(integer){
  return integer < 10 ? '0'+integer : ''+integer;
}

//Cents to euros: gets cent ammount as a number, returns strings as euro
function cents_to_euro_string(cent_number) {
  var cents = cent_number % 100;
  var euros = (cent_number - cents) / 100;
  return ''+euros+'.'+leftpad_str(cents)+'€'
}


// Format strings, taken from SO

if (!String.format) {
  String.format = function(format) {
    var args = Array.prototype.slice.call(arguments, 1);
    return format.replace(/{(\d+)}/g, function(match, number) {
      return typeof args[number] != 'undefined'
        ? args[number]
        : match
      ;
    });
  };
}
