/* JSON information about every menu available */

function get_restaurants() {
  var restaurants = {
    'lanonia': {
      'name': 'A Lanonia',
      'description': 'Snacks tradicionais feitos ao gosto do freguês',
      'logo':'./assets/icons/alanonia.png',
      'initial': 'L',
      'drinks':['alcohol'] ,/* drink types available in restaurant  -> allows for specialization: eg. vegetarian restaurant */
      'snacks':['generic'],
      'menus':['vegetarian'],
    },
    'ze': {
      'name': 'Tasca do Zé',
      'description': 'Bebida vegetariana feita pelo famoso Zé da Vila da Esquina',
      'logo':'./assets/icons/tascadoze.png',
      'initial': 'Z',
      'drinks':['beverages'] ,/* drink types available in restaurant  -> allows for specialization: eg. vegetarian restaurant */
      'snacks':['generic'],
      'menus':['fast-food'],
    },
    'cia': {
      'name': 'CIA',
      'description': 'Menus especiais como nunca viu',
      'initial': 'C',
      'logo':'./assets/icons/acia.png',
      'drinks':['alcohol'] ,/* drink types available in restaurant  -> allows for specialization: eg. vegetarian restaurant */
      'snacks':['generic'],
      'menus':['fast-food'],
    },
  }
  return restaurants;
}

function get_food_avail() {
  var food_avail = {
    "drinks": { /* food type */
      'alcohol': { /* sub-food type */
        'sangria1l': {
          'prices':[120,130,140],
          'description':'Sangria 1L',
          'image':'sangria.png', /* only the name of the file */
          'time': 3,
        }, 'cerveja05l': {
          "prices": [100,120,150],
          'description':'Cerveja 0.5L',
          'image':'cerveja.png',
          'time': 3,
        }, 'champagne02l' :{
          "prices":[169,190,220],
          'description':'Champagne 200ml',
          'image':'champagne.png',
          'time': 3,
        },
      },
      'beverages': { /* sub-food type */
        'cola': {
          'prices':[120,130,140],
          'description':'Cola 33cl',
          'image':'cola.png',
          'time': 3,
        }, 'seven_up': {
          "prices":[80,90,120],
          'description':'7up 33cl',
          'image':'seven_up.png',
          'time': 3,
        }, 'orage_juice' :{
          "prices":[169,190,220],
          'description':'Sumo de Laranja',
          'image':'orange_juice.png',
          'time': 3,
        },
       }
     },
    "snacks": { /* food type */
      'generic': { /* sub-food type */
        'snickers': {
          'prices':[120,130,140],
          'description':'Barra de Snickers',
          'image':'snickers.png',
          'time': 3,
        }, 'potatoes': {
          "prices":[80,90,120],
          'description': 'Batatas Fritas',
          'image':'chips.png',
          'time': 3,
         }
       }
     },
    "menus": { /* food type */
      'vegetarian': { /* sub-food type */
        'salada_gurmet': {
          'prices':[420,430,440],
          'description':'Salada Gourmet',
          'image':'salada.png',
          'time': 5,
        }, 'wrap': {
          'prices':[80,90,120],
          'description': 'Wrap Legumes',
          'image':'wrap_legumes.png',
          'time': 7,
        }, 'hamburguer_vegan': {
          'prices':[520,530,540],
          'description': 'Hamburguer Vegan',
          'image':'veggie_burguer.png',
          'time': 9,
        }
       },
       'fast-food': {
         'hamburguer': {
           'prices':[520,530,540],
           'description': 'Hamburguer',
           'image':'hamburguer.png',
           'time': 6,
         }
       }
     }
   }
   return food_avail;
 }

/*Food functionality*/

/* JSON generators for food menus */


function json_show_desc(rest) {
  var restaurant = get_restaurants()[rest]

  var json = { screen:
                {type: "info",
                 title: restaurant['name'],
                /*image: restaurante['logo'],  <-- on purpose commented out, we do not want logos here (?)*/
                 content: restaurant['description'],
                 click: restore_last_screen
               },
               bar:
               { type:'uni',
                  array:[{logo:"./assets/icons/undo.svg", style:"bar-color_blue_circle_uni", click: restore_last_screen} ]
               }

             }

  return json;
}


function json_gen_restaurants() {
  var restaurants = get_restaurants();
  var views = [];


  var c = function(){
    for (var rest in restaurants)
      if(!restaurants[rest].hasOwnProperty('logo') || restaurants[rest]['logo'] === '') {
        $("#" + rest + " .slider_menu-logo").css("font-size","1.5cm").html(restaurants[rest]['initial'])
      }

  }

  for (var rest in restaurants)
    views.push({title:'Restaurante', label:restaurants[rest]['name'], logo:restaurants[rest]['logo'], id:rest})

  var json = { screen:
               {type:"slider_menu",
                onrestore:"confirm_go_back",
                click:function(){var c=get_slider_selected_id();Cookies.set('restaurant',c);set_screen('food_screen')},
                views: views,
                callback: c
               },
               bar:
                 {type:"triple",
                 array:[{logo:"./assets/icons/undo.svg","style":"bar-color_blue_circle","click":restore_last_screen},
                        {logo:"./assets/icons/info.svg", style:"bar-color_blue_circle", click:function(){set_screen(json_show_desc(get_slider_selected_id()));}},
                        {logo:"./assets/icons/ok.svg","style":"bar-color_blue_circle","click":function(){Cookies.set('restaurant',get_slider_selected_id());set_screen('food_screen')}}]
              }
            }

  return json;
}





/* generates a given type of food for a given restaurant
 * it does so, through a hash function
 */
var food_listed = [] // helps in getting the food name from owlCarousel
function json_gen_food(food_type, restaurant) {
  var restaurants = get_restaurants();
  var food_avail = get_food_avail();
   /* generating views*/
   /* view template : {title:"","logo":"./assets/icons/drink.svg",label:"Bebidas",id:"drinks" */
   views = [];
   food_listed = []
   console.log(restaurants[restaurant][food_type])
   for (var sub_type in restaurants[restaurant][food_type]) { /* iterates through different sub-types of food*/
     var sub_type = restaurants[restaurant][food_type][sub_type]
     console.log("current sub-type is: ", sub_type)
     for (var food_name in food_avail[food_type][sub_type]) {
       var food_props = food_avail[food_type][sub_type][food_name]
       console.log(food_name+": ")
       console.log(food_props)
       food_listed.push(food_name)
       views.push({title:food_props['description'],logo:get_food_image(food_type, food_props['image']),label:cents_to_euro_string(food_props['prices'][0]),id:food_name})

     }
   }
   var json = {screen:
                   {type:"slider_menu_ammount",
                    views: views,
                    callback:function(){init_ammount_selector(0,5,decrease_food,increase_food,food_order_listen);update_ok_button_food()} /* sets up the event listeners */
                   },
               bar:
                   {type:"double",
                   array:[
                     {logo:"./assets/icons/undo.svg",style:"bar-color_yellow",click:restore_last_screen},
                     {logo:"./assets/icons/ok.svg",style:"bar-color_green",click:function(){food_order_exists() && set_screen(json_gen_food_total());} } ]
                  }
             }

  return json;
}


function json_gen_food_total() {
  var timeout_var = -1;
  json = {screen:
            { type:'info',
              title:'Total: '+cents_to_euro_string(get_food_price()),
              image:'',
              content:'Confirme a Encomenda',
              callback: function(){ timeout_var = setTimeout(set_screen,1200,json_gen_food_total_confirm_food());}
            },
          bar:
            { type:'double',
              array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:restore_last_screen},
                      {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:function(){clearTimeout(timeout_var); set_screen(json_gen_food_total_confirm_food());} } ]
            }
          }

 return json;
}

function json_gen_food_total_confirm() {
  json = {screen:
            { type:'info',
              title:'Total: '+cents_to_euro_string(get_food_price()),
              image:'',
              content:'Continuar?',
            },
          bar:
            { type:'double',
              array:[ {logo:"./assets/icons/undo.svg", style:"bar-color_yellow", click:function(){set_screen("food_cancel_order")}},
                      {logo:"./assets/icons/ok.svg", style:"bar-color_green", click:function(){set_screen(json_gen_food_order_placed())} } ]
            }
          }

 return json;
}

function json_gen_food_total_confirm_food(food_type, restaurant) {
  /* generating views*/
  /* view template : {title:"","logo":"./assets/icons/drink.svg",label:"Bebidas",id:"drinks" */
  views = [];
  food_listed = []
  food_avail = get_food_avail();
  for (food_type in food_avail){
    for (sub_type in food_avail[food_type]){
      for (food_name in food_avail[food_type][sub_type]){
        if (current_food_order.hasOwnProperty(food_name)){ // if the basket has product
          console.log("found!!! "+food_name)
          food_listed.push(food_name)
          food_props = food_avail[food_type][sub_type][food_name]
          views.push({title:food_props['description'],logo:get_food_image(food_type, food_props['image']),label:cents_to_euro_string(food_props['prices'][0]),id:food_name})
        }
      }
    }
  }
  var json = {screen:
                 {type:"slider_menu_ammount",
                  views: views,
                  callback: function(){init_ammount_selector(0,5,decrease_food,increase_food,food_order_listen);} /* sets up the event listeners */
                 },
             bar:
                 {type:"double",
                 array:[
                   {logo:"./assets/icons/undo.svg",style:"bar-color_yellow",click:function(){restore_last_screen();restore_last_screen();restore_last_screen();}},
                   {logo:"./assets/icons/ok.svg",style:"bar-color_green",click:function(){set_screen(json_gen_food_total_confirm());} } ]
                }
           }

  return json;
}



// Not yet used
// TODO:
//   - In general, we need to detect collision of times in taxi ride and food orders
//   - Make time_to_go depend if there are menus, drinks or food, and number(?) enhancement
function json_gen_food_order_placed(){
  console.log(current_food_order)

  var max = 0
  food_avail = get_food_avail();

  for (food_type in food_avail){
    for (sub_type in food_avail[food_type]){
      for (food_name in food_avail[food_type][sub_type]){
        if (current_food_order.hasOwnProperty(food_name)){ // if the basket has product
          food_props = food_avail[food_type][sub_type][food_name]
          if (food_props['time'] > max){
            max = food_props['time']
          }
        }
      }
    }
  }


  var time_to_go = max // In minutes

  //TODO: why !food_order_exists? This means no current food order....
  // Commenting it out from here fixed a bug
  var c = function(){
            build_notification(time_to_go*1000*60, "Food order", "food_order_almost_arrived","no info","food");
            go_to_first_screen_and_discard()
          }


  var json= {screen:
              { type:'info',
                title:'Encomendado',
                content:'será alertado daqui a<br>' + time_to_go + ' min',
                click: function(){c();Cookies.set("when-arrived-at-dest","food_collect_food")},
              },
            bar:
              { type:'uni',
                array:[ {logo:"./assets/icons/ok.svg", style:"bar-color_blue_circle_uni", click:  function(){c();Cookies.set("when-arrived-at-dest","food_collect_food")} }]
              }
            };


  return json;
}




/*
 * Food Related Functions
 */

function get_food_image(food_type, food_image_name) {
  if(food_image_name != undefined && food_image_name != '')
    return "./assets/icons/food/"+food_type+"/"+food_image_name
  else
    return ''
}


/* food related variables */
var old_food_orders = []
var current_food_order = {}

/* sets-up the event listeners for ordering food */
function food_order_listen() {
 $('.owl-carousel').on('changed.owl.carousel', function(e) {

   // NOTE: get_slider_selected_id was not working so we access trough the indexes
   //console.log("now selected "+food_listed[e.item.index])
   var food_name = food_listed[e.item.index]
   update_food_ammount(food_name);
 });
}

/* initializes a food ordering */
function init_food_order() {
 current_food_order = {} // resets the vector
}

/* saves the old food order */
function new_food_order() {
 old_food_orders.push(current_food_order);
 current_food_order = {} // resets the vector
}

/* discards the current food order and starts a new one*/
function discard_food_order(){
  current_food_order = {}
}

function food_order_exists(){
  console.log("food order exists: ", !jQuery.isEmptyObject(current_food_order))
  return !jQuery.isEmptyObject(current_food_order);
}

function decrease_food(){
 //set_ammount_selector_ammount(get_ammount_selector_ammount()-1)

 set_current_ammount(get_current_ammount()-1)
 set_ammount_selector_ammount("",get_current_ammount(),"")

 update_food_order()
 update_ok_button_food()
}
function increase_food(){
 //set_ammount_selector_ammount(get_ammount_selector_ammount()+1)

 set_current_ammount(get_current_ammount()+1)
 set_ammount_selector_ammount("",get_current_ammount(),"")

 update_food_order()
 update_ok_button_food()
}

/* enables or disables the ok button depending on wether or not there is food in the basket */
function update_ok_button_food(){
  if (!food_order_exists()) $("#btn1_icon").css("opacity","0.6")
  else $("#btn1_icon").css("opacity","1.0")
}

/* updates the screen to show the current ammount of the selected view
this is the callback function when owlCarousel is dragged */
function update_food_ammount(food_name){
 //set_ammount_selector_ammount(get_food_ammount(food_name))
 current_ammount = get_food_ammount(food_name);
 set_ammount_selector_ammount("",current_ammount,"");
}

/* gets the ammount selected by the selector*/
function get_food_ammount(food_name){
 var ammount;
 if (current_food_order.hasOwnProperty(food_name)){
   ammount = current_food_order[food_name]
 } else {
   ammount = 0
 }
 return ammount
}

function update_food_order(){
 var food_name = get_slider_selected_id()
 //var ammount = get_ammount_selector_ammount()
 var ammount = get_current_ammount()
 if (ammount == 0) delete current_food_order[food_name]
 else current_food_order[food_name] = ammount;
}

function get_food_price(){
  console.log("price")
  total=0;
  food_avail = get_food_avail();
  for (food_type in food_avail){
    for (sub_type in food_avail[food_type])
    for (food in food_avail[food_type][sub_type]){
      if (current_food_order.hasOwnProperty(food)){ // if the basket has product
        price = food_avail[food_type][sub_type][food]["prices"][0]
        num_items = current_food_order[food]
        total += price * num_items
      }
     }
  }
  return total
}


function confirm_go_back(){
  if( food_order_exists() ) {
    // Put back this element on the screen_stack
    put_back_stack_element(this)
    this.use_this = false
    // Put up a confirm screen
    console.log('Confirm going back')
    set_screen("food_cancel_order")
  } else {
    // Do nothing: no order was made
  }
}
