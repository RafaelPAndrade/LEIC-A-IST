/*
 * Code for making general-purpose notifications
 */


/*This array has objects with fields:
 * - The function to run when the time is up
 *   OR
 *   a spec screen to put up (JSON, unquoted functions)
 * - Time when notification is up (only used to show on the table and cleanup)
 * - Type : ["ride","food"]
 * - Name/Identification (to show on a table)
 * - Timeout id
 * - Info: anything that we can use later (eg food order, type of ride, etc)  */

notification_array=[]

// "Constructor" of notifications
function build_notification(time_offset, name, main_thing, info, type){

  var res = {}
  res.name = name
  res.type = type
  res.main = main_thing // Later we see if it is an object or a function
  res.info = info

  res.time = new Date(new Date().getTime() + time_offset)
  res.timeout = setTimeout(nget_func(res), time_offset)
  notification_array.push(res);
  show_all_in_table();
  return res;
}



// Sorts and removes notifications whose time already passed
function cleanup_array(){

  function cmp(n1,n2){
    return n1.time - n2.time
  }

  notification_array.sort(cmp)

  current_date = new Date();
  while(notification_array.length > 0 && notification_array[0].time < current_date){
    if (notification_array[0].type == "ride"){
      delete_ride();
      console.log("deleting rideeeeeee")
    }
    notification_array.shift()
  }
}

function show_all_in_table(){


  function gen_row(n){
    return $(String.format('<tr><td>{0}</td><td>{1}h{2}:{3}</td><td><button id="{0}">Trigger</button></td>',
                           n.name, leftpad_str(n.time.getHours()), leftpad_str(n.time.getMinutes()),
                           leftpad_str(n.time.getSeconds()))).click(nget_func(n))
  }

  var $table = $("#notifications_table")
  $table.empty()

  cleanup_array();
  for(var i=0; notification_array.length > i; ++i){
    $table.append(gen_row(notification_array[i]));
  }

}


function delete_all_notifications(){
  for(n in notification_array) {
    clearTimeout(n.timeout)
  }

  notification_array=[]
  show_all_in_table()
}

/*Do not use these directly outside of this file*/

function nremove_me_from_array(n){
  var i = notification_array.indexOf(n)
  if (i>-1) {
    clearTimeout(notification_array[i].timeout)
    notification_array.splice(i,1);
  }
  show_all_in_table();
}

function nget_func(n){
  if(typeof n.main !== "function") {
    return function(){ nremove_me_from_array(n); set_screen(n.main) }
  } else {
    return function(){ nremove_me_from_array(n); n.main.call(n) }
  }
}
