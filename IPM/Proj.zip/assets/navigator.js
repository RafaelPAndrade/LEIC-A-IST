
function update_navigator(angle) {
  $('#navigator_image').transition({ rotate: angle+'deg' });
}

var distance_left
var position = 0
var sub_path_position = 0;
var path_timeouts = []
path = [] // sequence of distances and angles alternating
path_index = 0 // indicates in which part of the path we are

/* makes some fancy compass animations*/
function navigate(){
  $("#navigator_image").css('margin-top','12px')
  //$("#image").css("opacity","0.5") // just for debugging
  //$('#path_bottom').css("transform",'rotate(180deg)')
  distance = Math.floor((Math.random() * 200) + 15);
  distance_left = distance
  velocity = 1 // 1 meter per second
  path = gen_path(distance)
  while (distance_left >= 0) {
    position = distance - distance_left;
    path_timeouts.push(setTimeout(update_steps, position*100))
    distance_left -= 1;
  }
  distance_left = distance; // resets such that update_steps works
  position = 0
  sub_path_position = 0;

}

function update_steps() {
  $info_contet = $("#info-content").children(":first").html(distance_left + " passos")
  distance_left--;
  position++;
  sub_path_position ++;
  if (sub_path_position >= path[path_index]) { // if it has reached the end of the subpath
    //if (!(path_index+3>= path.length-1))$('#path_top').transition({ rotate: path[path_index+3]+'deg' }); // shows the next rotation
    //$('#path_bottom').transition({ rotate: path[path_index+1]+180+'deg' }); // shows the next rotation
    update_navigator(path[path_index+1]); // updates the angle
    path_index+=2;
    sub_path_position = 0
  }
  if (distance_left < 0) set_screen("navigator_dest_reached")
}

/* returns a path */
function gen_path(total_distance) {
  var position = 0;
  path_index = 0
  path = [];
  while (position <= total_distance-5) {
    distance_subpath = Math.floor((Math.random() * (total_distance-position)/2 + 10))
    position = position + distance_subpath
    path.push(distance_subpath)

    angle = Math.floor((Math.random()*60 + 30))
    if (Math.random()>0.5) angle = -1*angle // randomly chooses a side
    path.push(angle)
  }
  return path
}

function clear_path_timeouts(){
  for (var i=0; i<path_timeouts.length; i++) {
    clearTimeout(path_timeouts[i]);
  }
}
