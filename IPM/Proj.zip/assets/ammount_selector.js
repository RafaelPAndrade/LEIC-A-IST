/*
 * This file contains functions related to the ammount selector
 *        --- as well as some documentation ---
 */

/* NOTE: Instructions for creating an ammount_selector

include the following html:
  <div class="ammount-selector">
    <div onclick="decrease()" id="decrease" class="selector_left" >
      <img id="negative" src="./assets/icons/negative.svg">
    </div>
    <div id="ammount_selected" class="selector_center" >1<div>
    <div onclick="increase()" id="increase" class="selector_right" >
      <img id="positive" src="./assets/icons/plus.svg">
    </div>
  </div>

  1. create decrease function
  2. create increase function
  3. initialize the function : init_ammount_selector()

  interaction with the bar using these getters and setters:
    get_ammount_selector_ammount()
    set_ammount_selector_ammount()

*/

/* globals */
as_min=0
as_max=1000
decrease_func=function(){}
increase_func=function(){}
current_ammount = 0;

/** initializes the ammount selector
 * @param  {int} min minumum ammount selectable
 * @param  {int} max maximum ammount selectable
 * @param  {function} decrease function for decreasing
 * @param  {function} increase function for increasing
 * @param  {function} event_listener (optional) event listener function - used for example
 * for adding an event listener for owlCarousel changed listener
 */
function init_ammount_selector(min, max, decrease, increase, event_listener){
  current_ammount = min; /* de default ammount is the minimum */
  as_min = min
  as_max = max
  decrease_func=decrease
  increase_func=increase

  // if event_listener is in the argument, call it
  if(typeof event_listener !== "undefined") event_listener.call()
}

function decrease(){decrease_func.call()}
function increase(){increase_func.call()}


// getters and setters
function get_current_ammount() {
  return current_ammount;
}

function set_current_ammount(new_ammount){
  current_ammount = new_ammount;
}

function set_ammount_selector_ammount(text_before,ammount,text_after){
  $(".ammount_selected").html(text_before+ammount+text_after);

  if (ammount <= as_min) {
    disable_negative()
    enable_positive()
  } else if (ammount >= as_max) {
    enable_negative()
    disable_positive()
  }
  else {
    enable_positive()
    enable_negative()
  }

}

/* Enabling or disabling of buttons
  NOTE: when called these functions try to change the state
  but if it was already in that state there are no side-effects */
function enable_positive(){
  $("#positive").attr("src","./assets/icons/plus.svg")
  command = $("#increase").attr("onclick")
  if (command.indexOf("return;")==0) { // if it is already disabled
    command = command.substring("return;".length) // removes the return
  }
  $("#increase").attr("onclick",command)
}

function disable_positive(){
  $("#positive").attr("src","./assets/icons/plus_disabled.svg")
  command = $("#increase").attr("onclick")
  command = "return;"+command
  $("#increase").attr("onclick",command)
}

function enable_negative(){
  $("#negative").attr("src","./assets/icons/negative.svg")
  command = $("#decrease").attr("onclick")
  if (command.indexOf("return;")==0) { // if it is already disabled
    command = command.substring("return;".length)
  }
  $("#decrease").attr("onclick",command)
}

function disable_negative(){
  $("#negative").attr("src","./assets/icons/negative_disabled.svg")
  command = $("#decrease").attr("onclick")
  command = "return;"+command
  $("#decrease").attr("onclick",command)
}
